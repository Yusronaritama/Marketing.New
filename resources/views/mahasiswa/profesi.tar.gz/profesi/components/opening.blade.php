{{-- resources/views/mahasiswa/profesi/components/opening.blade.php --}}
<div x-data="{ showOpening: true }" 
     x-init="setTimeout(() => showOpening = false, 2000)" 
     x-show="showOpening" 
     x-transition:leave="transition ease-in-out duration-700" 
     x-transition:leave-start="opacity-100 scale-100" 
     x-transition:leave-end="opacity-0 scale-110" 
     class="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-white"
     style="display: flex;"> {{-- Pakai style flex biar gak kedip di awal --}}
     
    {{-- Lingkaran Efek Pulse --}}
    <div class="relative flex items-center justify-center">
        <div class="absolute w-32 h-32 bg-blue-100 rounded-full animate-ping opacity-60"></div>
        
        {{-- Logo UBP --}}
        <div class="relative z-10 w-24 h-24 bg-white rounded-full shadow-xl border border-gray-100 flex items-center justify-center p-2">
            <img src="{{ asset('images/logo_ubp.png') }}" alt="Logo UBP" class="w-full h-auto" onerror="this.onerror=null; this.src='https://ubpkarawang.ac.id/wp-content/uploads/2021/08/Logo-UBP-Karawang.png';">
        </div>
    </div>

    {{-- Teks Animasi --}}
    <div class="mt-6 text-center animate-pulse">
        <h2 class="text-xl font-black text-gray-900 tracking-wider">PMB <span class="text-blue-600">PROFESI</span></h2>
        <p class="text-sm font-semibold text-gray-500 mt-1">Universitas Buana Perjuangan</p>
    </div>
</div>