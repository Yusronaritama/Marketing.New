@extends('layouts.mahasiswa.profesi')

@section('title', 'Dashboard ' . $namaProfesi)


@include('mahasiswa.profesi.components.opening')
@include('mahasiswa.profesi.components.maintenance')
@include('mahasiswa.profesi.components.warning')


@section('content')
<div class="min-h-screen bg-gray-50 py-8 px-4 sm:px-6">
    {{-- Pembungkus utama dengan lebar maksimal (Tengah di PC, Full di Mobile) --}}
    <div class="max-w-3xl mx-auto space-y-6">

        {{-- ==========================================
             1. WARNING BANNER (Paling Atas)
             ========================================== --}}
        <div class="bg-amber-50 border-l-4 border-amber-500 p-4 rounded-r-xl shadow-sm flex items-start gap-4">
            <div class="text-amber-500 mt-1">
                <i class="fas fa-exclamation-circle text-xl animate-pulse"></i>
            </div>
            <div>
                <h3 class="text-sm font-bold text-amber-800 uppercase tracking-wider">Pendaftaran Ditunda</h3>
                <p class="text-sm text-amber-700 mt-1">
                    Jalur pendaftaran untuk <strong>{{ $namaProfesi }}</strong> sedang dalam tahap sinkronisasi jadwal. Pantau dashboard secara berkala.
                </p>
                <p class="text-sm text-amber-700 mt-1">
                    Upload berkas akan dibuka pada tanggal 22.
                </p>
            </div>
        </div>

        {{-- ==========================================
             2. KARTU IDENTITAS & PROGRAM
             ========================================== --}}
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col sm:flex-row items-center sm:items-start gap-4 text-center sm:text-left">
            <div class="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center shrink-0">
                <i class="fas fa-user-graduate text-2xl"></i>
            </div>
            <div class="flex-1">
                <h2 class="text-xl font-bold text-gray-900">{{ $user->name }}</h2>
                <p class="text-sm text-gray-500 mb-3">{{ $user->email }} &bull; {{ $user->phone ?? 'No. HP Belum Diisi' }}</p>
                <span class="inline-block bg-indigo-50 text-indigo-700 text-xs font-bold px-3 py-1 rounded-full border border-indigo-100">
                    <i class="fas fa-stethoscope mr-1"></i> Pilihan: {{ $namaProfesi }}
                </span>
            </div>
        </div>

        {{-- ==========================================
             3. KARTU STEPPER ALUR PENDAFTARAN
             ========================================== --}}
        <div class="bg-white p-6 sm:p-8 rounded-2xl shadow-sm border border-gray-100">
            <div class="text-center sm:text-left mb-8">
                <h3 class="text-lg font-bold text-gray-900">Alur Pendaftaran</h3>
                <p class="text-sm text-gray-500 mt-1">Selesaikan setiap tahapan untuk menjadi mahasiswa {{ $namaProfesi }}.</p>
            </div>

            {{-- Container Stepper --}}
            <div class="relative flex flex-col sm:flex-row justify-between gap-8 sm:gap-0 mt-4">
                
                {{-- Garis Penghubung (Tampil Horizontal di PC) --}}
                <div class="hidden sm:block absolute top-6 left-0 w-full h-1 bg-gray-200 z-0"></div>
                {{-- Garis Penghubung (Tampil Vertical di Mobile) --}}
                <div class="sm:hidden absolute top-0 left-6 w-1 h-full bg-gray-200 z-0"></div>

                {{-- STEP 1: Upload Berkas (Status Saat Ini) --}}
                <div class="relative z-10 flex sm:flex-col items-center gap-4 sm:gap-3 flex-1">
                    {{-- Efek Denyut karena ini tahap yang harus dikerjakan / ditunggu --}}
                    <div class="w-12 h-12 rounded-full flex items-center justify-center text-white bg-blue-600 ring-4 ring-white shadow-md relative">
                        <div class="absolute w-full h-full rounded-full border-4 border-blue-400 animate-ping opacity-50"></div>
                        <span class="font-bold">1</span>
                    </div>
                    <div class="text-left sm:text-center">
                        <p class="text-sm font-bold text-blue-700">Upload Berkas</p>
                        <p class="text-xs text-gray-500 mt-0.5">Menunggu Jadwal</p>
                    </div>
                </div>

                {{-- STEP 2: Test CBT (Terkunci) --}}
                <div class="relative z-10 flex sm:flex-col items-center gap-4 sm:gap-3 flex-1">
                    <div class="w-12 h-12 rounded-full flex items-center justify-center font-bold text-gray-500 bg-gray-200 ring-4 ring-white">
                        2
                    </div>
                    <div class="text-left sm:text-center opacity-60">
                        <p class="text-sm font-bold text-gray-700">Test CBT</p>
                        <p class="text-xs text-gray-500 mt-0.5">Terkunci</p>
                    </div>
                </div>

                {{-- STEP 3: Wawancara (Terkunci) --}}
                <div class="relative z-10 flex sm:flex-col items-center gap-4 sm:gap-3 flex-1">
                    <div class="w-12 h-12 rounded-full flex items-center justify-center font-bold text-gray-500 bg-gray-200 ring-4 ring-white">
                        3
                    </div>
                    <div class="text-left sm:text-center opacity-60">
                        <p class="text-sm font-bold text-gray-700">Wawancara</p>
                        <p class="text-xs text-gray-500 mt-0.5">Terkunci</p>
                    </div>
                </div>

                {{-- STEP 4: Pembayaran UKT (Terkunci) --}}
                <div class="relative z-10 flex sm:flex-col items-center gap-4 sm:gap-3 flex-1">
                    <div class="w-12 h-12 rounded-full flex items-center justify-center font-bold text-gray-500 bg-gray-200 ring-4 ring-white">
                        4
                    </div>
                    <div class="text-left sm:text-center opacity-60">
                        <p class="text-sm font-bold text-gray-700">Bayar UKT</p>
                        <p class="text-xs text-gray-500 mt-0.5">Terkunci</p>
                    </div>
                </div>

                {{-- STEP 5: Finish (Terkunci) --}}
                <div class="relative z-10 flex sm:flex-col items-center gap-4 sm:gap-3 flex-1">
                    <div class="w-12 h-12 rounded-full flex items-center justify-center font-bold text-gray-500 bg-gray-200 ring-4 ring-white">
                        <i class="fas fa-flag-checkered"></i>
                    </div>
                    <div class="text-left sm:text-center opacity-60">
                        <p class="text-sm font-bold text-gray-700">Selesai (100%)</p>
                        <p class="text-xs text-gray-500 mt-0.5">Info Lanjut</p>
                    </div>
                </div>

            </div>
        </div>
        
        {{-- ==========================================
             4. KARTU AKSI: UPLOAD BERKAS (Tahap 1)
             ========================================== --}}
        <div class="bg-white p-6 sm:p-8 rounded-2xl shadow-sm border border-gray-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
            
            {{-- Bagian Kiri: Info & Status --}}
            <div class="flex-1">
                <h3 class="text-lg font-bold text-gray-900">Tahap 1: Upload Berkas Persyaratan</h3>
                <p class="text-sm text-gray-500 mt-1">Silahkan unggah semua dokumen persyaratan untuk diverifikasi oleh Pihak Kampus.</p>

                {{-- Badges Status (Contoh Logika UI) --}}
                <div class="flex flex-wrap gap-2 mt-4">
                    
                    {{-- 1. Status Upload Berkas --}}
                    {{-- Nanti ganti false dengan variabel asli dari DB kamu misal $isBerkasLengkap --}}
                    @if(false) 
                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            <i class="fas fa-check-circle"></i> Berkas Diupload
                        </span>
                    @else
                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
                            <i class="fas fa-times-circle"></i> Belum Upload Berkas
                        </span>
                    @endif

                    {{-- 2. Status Verifikasi Farmasi --}}
                    {{-- Nanti sesuaikan logikanya dengan tabel FarmasiVerification di DB --}}
                    @php $statusVerif = 'belum'; /* Contoh: belum, proses, lulus, tolak */ @endphp
                    
                    @if($statusVerif == 'lulus')
                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
                            <i class="fas fa-user-check"></i> Diverifikasi Farmasi
                        </span>
                    @elseif($statusVerif == 'proses')
                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
                            <i class="fas fa-clock"></i> Menunggu Verifikasi
                        </span>
                    @else
                        <span class="inline-flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-bold bg-gray-100 text-gray-600 border border-gray-200">
                            <i class="fas fa-minus-circle"></i> Verifikasi: Belum Tersedia
                        </span>
                    @endif
                    
                </div>
            </div>

            {{-- Bagian Kanan: Tombol Redirect --}}
            <div class="w-full sm:w-auto">
                @if(!$isPendaftaranBuka)
                    {{-- Jika jadwal belum buka (Digembok) --}}
                    <button disabled class="w-full sm:w-auto px-6 py-3 bg-gray-200 text-gray-500 font-bold rounded-xl cursor-not-allowed flex items-center justify-center gap-2 transition">
                        <i class="fas fa-lock"></i> Jadwal Belum Buka
                    </button>
                @else
                    {{-- Jika jadwal sudah buka (Bisa di-klik) --}}
                    {{-- Nanti ganti '#' dengan route form upload berkas profesi kamu --}}
                    <a href="#" class="w-full sm:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 transition hover:-translate-y-0.5">
                        <i class="fas fa-cloud-upload-alt"></i> Upload Sekarang
                    </a>
                @endif
            </div>

        </div>

        {{-- ==========================================
             5. KARTU PERSIAPAN BERKAS (To-Do List Style)
             ========================================== --}}
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <div class="flex items-center gap-3 mb-4">
                <div class="w-8 h-8 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center">
                    <i class="fas fa-file-pdf text-sm"></i>
                </div>
                <h3 class="text-md font-bold text-gray-800">Persiapan Dokumen</h3>
            </div>
            <p class="text-sm text-gray-600 mb-4">Sambil menunggu jadwal buka, siapkan dokumen berikut dalam format digital (PDF/JPG):</p>
            
            {{-- Grid Checklist Berkas --}}
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div class="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-100">
                    <i class="far fa-circle text-gray-300"></i>
                    <span class="text-sm font-medium text-gray-700">Ijazah S1 Terkait</span>
                </div>
                <div class="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-100">
                    <i class="far fa-circle text-gray-300"></i>
                    <span class="text-sm font-medium text-gray-700">Transkrip Nilai Akademik</span>
                </div>
                <div class="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-100">
                    <i class="far fa-circle text-gray-300"></i>
                    <span class="text-sm font-medium text-gray-700">Kartu Tanda Penduduk (KTP)</span>
                </div>
                <div class="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-100">
                    <i class="far fa-circle text-gray-300"></i>
                    <span class="text-sm font-medium text-gray-700">Kartu Keluarga (KK)</span>
                </div>
            </div>
        </div>

    </div>
</div>
@endsection