<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use App\Models\SlikBilling;
use App\Models\MasterEreg;
use App\Models\ProgramStudi;

class SyncQuotaSeats extends Command
{
    protected $signature = 'quota:sync';
    protected $description = 'Menyapu transaksi PAID, kunci jurusan kelulusan, dan sinkronisasi kuota';

    public function handle()
    {
        $this->info('🚀 Memulai Sapu Bersih Transaksi...');
        
        $diupdate = 0;

        SlikBilling::whereRaw('LOWER(status) IN (?, ?)', ['paid', 'lunas'])
            ->orderBy('datetime_payment', 'asc')
            ->chunk(100, function ($billings) use (&$diupdate) {
                
                foreach ($billings as $bill) {
                    try {
                        $ereg = MasterEreg::where('user_id', $bill->user_id)->first();

                        // Skip jika user tidak ditemukan atau SUDAH dapat stempel lunas
                        if (!$ereg || $ereg->is_quota_taken == 1) {
                            continue; 
                        }

                        // 1. Beri stempel lunas
                        $ereg->is_quota_taken = 1;
                        
                        // 2. Kunci jurusan finalnya MURNI berdasarkan kode prodi di tagihan yang dibayar!
                        // (Ini otomatis menyelesaikan masalah anak Farmasi yang nyasar ke pilihan 2)
                        $ereg->jurusan_lulusan = $bill->kode_prodi;
                        
                        $ereg->save();
                        $diupdate++;

                        $this->info("✅ [LUNAS] User {$bill->user_id} -> Terkunci di Prodi: {$bill->kode_prodi}.");

                    } catch (\Exception $e) {
                        $this->error("Err User {$bill->user_id}: " . $e->getMessage());
                    }
                }
            });

        // 3. JIKA ADA YANG BERUBAH, HITUNG ULANG SEMUA KUOTA PAKAI RUMUS SUCI KITA
        if ($diupdate > 0) {
            $this->info("🔄 Mensinkronisasi ulang kuota seluruh Program Studi...");
            
            ProgramStudi::all()->each(function($prodi) {
                $prodi->syncDayaTampung();
            });
        }

        $this->info("🎯 Selesai! {$diupdate} pendaftar baru berhasil disinkronkan ke kuotanya masing-masing.");
        return Command::SUCCESS;
    }
}