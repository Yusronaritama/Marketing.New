<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use App\Models\MasterEreg;
use App\Models\MasterMoodleLulus;

class SyncMoodleLulusCommand extends Command
{
    // Ini nama perintah yang bakal dipanggil di terminal nanti
    protected $signature = 'pmb:sync-moodle-lulus';

    // Deskripsi singkat perintahnya
    protected $description = 'Otomatis sinkronisasi data jurusan_lulusan dari master_moodle_lulus ke master_ereg';

    public function handle()
    {
        $this->info('Memulai proses sinkronisasi Moodle Lulus...');
        
        try {
            $moodleLulusan = MasterMoodleLulus::all();
            $updatedCount = 0;
            
            $this->info("Ditemukan " . $moodleLulusan->count() . " data di tabel Moodle Lulus. Memulai pengecekan...");

            foreach ($moodleLulusan as $moodle) {
                if (!$moodle->master_user_id) {
                    continue;
                }

                // ========================================================
                // [BARU] JEMBATAN PENGHUBUNG ID (SOLUSI MISTERI KITA!)
                // ========================================================
                // Kita harus cari ID aslinya dulu di master_users
                $masterUser = \App\Models\MasterUser::find($moodle->master_user_id);
                
                if (!$masterUser) {
                    $this->warn("Master User ID {$moodle->master_user_id} gak ketemu. Skip!");
                    continue;
                }

                $realUserId = $masterUser->user_id; // Nah! Ini yang narik angka 3716 dawg!

                // Sekarang baru kita tembak ke master_ereg pakai ID yang bener
                $ereg = MasterEreg::where('user_id', $realUserId)
                                  ->where(function($query) {
                                      $query->whereNull('jurusan_lulusan')
                                            ->orWhere('jurusan_lulusan', '')
                                            ->orWhere('jurusan_lulusan', '-'); 
                                  })
                                  ->first();

                if ($ereg) {
                    $kodeProdiLulus = $moodle->prodi_lulus ?? $ereg->jurusan1;

                    if ($kodeProdiLulus) {
                        $ereg->update([
                            'status_lulus'    => 'LULUS', 
                            'jurusan_lulusan' => $kodeProdiLulus
                        ]);
                        $updatedCount++;
                        $this->line("<fg=green>Berhasil update Hassya dkk! Real User ID: {$realUserId} ke prodi {$kodeProdiLulus}</>");
                    }
                }
            }
            

            $this->info("Sinkronisasi selesai! Berhasil memperbarui {$updatedCount} data maba.");

        } catch (\Exception $e) {
            $this->error('Terjadi kesalahan saat sinkronisasi: ' . $e->getMessage());
        }

        return Command::SUCCESS;
    }
}