@extends('layouts.admin.app')

@section('title', 'Hasil Analisis')

@section('content')
<div class="rounded-lg bg-white p-6 shadow-theme-sm dark:bg-gray-dark">
    <div class="mb-6 flex items-center justify-between">
        <h2 class="text-title-md font-bold text-gray-900 dark:text-white">
            Hasil Analisis Per Gelombang
        </h2>
        <a href="{{ route('admin.show-all.export') }}" 
           class="rounded-lg bg-brand-500 px-4 py-2.5 text-sm font-medium text-white hover:bg-brand-600 transition-all flex items-center gap-2">
            <i class="fas fa-file-excel"></i> Export Data Excel
        </a>
    </div>
    
    <div class="mb-6 p-5 bg-white rounded-xl shadow-sm border-l-4 border-blue-600">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center">
            <div>
                <h3 class="text-lg font-bold text-gray-800 mb-1">
                    <i class="fas fa-chart-line mr-2 text-blue-600"></i>Ringkasan Data Pendaftaran
                </h3>
                <p class="text-gray-600 text-sm leading-relaxed">
                    Yang mendaftar ada <strong>{{ number_format($totalMahasiswa) }}</strong> mahasiswa dari registrasi ulang,
                    dan yang sudah upload berkas sekitar <strong>{{ number_format($totalBerkas) }}</strong> Berkas dengan jumlah registrasi ulang <strong>{{ number_format($totalBiodataOrang) }}</strong> orang. <br>
                    Data final untuk DIKTI yang sudah ditarik sebanyak <strong>{{ number_format($totalDikti) }}</strong> mahasiswa.
                </p>
            </div>
            
            <div class="mt-4 md:mt-0 flex flex-wrap gap-4 bg-gray-50 p-3 rounded-lg border border-gray-100">
                <div class="text-xs"><span class="inline-block w-4 h-4 bg-blue-500 text-white text-center rounded-sm font-bold mr-1">D</span> <span class="text-gray-500">= Diterima</span></div>
                <div class="text-xs"><span class="inline-block w-4 h-4 bg-yellow-500 text-white text-center rounded-sm font-bold mr-1">U</span> <span class="text-gray-500">= Ujian</span></div>
                <div class="text-xs"><span class="inline-block w-4 h-4 bg-green-500 text-white text-center rounded-sm font-bold mr-1">R</span> <span class="text-gray-500">= Registrasi</span></div>
                <div class="text-xs"><span class="inline-block w-4 h-4 bg-purple-500 text-white text-center rounded-sm font-bold mr-1">F</span> <span class="text-gray-500">= Final (Dikti)</span></div>
            </div>
        </div>
    </div>

    {{-- TABEL REKAP PER PRODI --}}
    <div class="overflow-x-auto mb-10">
        <table class="min-w-full border-collapse">
            <thead>
                <tr class="bg-gray-50 dark:bg-gray-800">
                    <th rowspan="2" class="border border-gray-200 px-4 py-3 text-center text-sm font-semibold text-gray-900 dark:border-gray-700 dark:text-white">Nama Prodi</th>
                    @for ($i = 1; $i <= 10; $i++)
                        <th colspan="4" class="border border-gray-200 px-4 py-3 text-center text-sm font-semibold text-gray-900 dark:border-gray-700 dark:text-white">Gelombang {{ $i }}</th>
                    @endfor
                    <th colspan="4" class="border border-gray-200 bg-brand-50 px-4 py-3 text-center text-sm font-semibold text-brand-600 dark:border-gray-700 dark:bg-brand-500/15 dark:text-brand-400">Total</th>
                    @auth
                    <th rowspan="2" class="border border-gray-200 px-4 py-3 text-center text-sm font-semibold text-gray-900 dark:border-gray-700 dark:text-white">Unduh</th>
                    @endauth
                </tr>
                <tr class="bg-gray-50 dark:bg-gray-800">
                    @for ($i = 1; $i <= 10; $i++)
                        <th class="border border-gray-200 px-3 py-2 text-center text-xs font-medium text-gray-600 dark:border-gray-700 dark:text-gray-400">D</th>
                        <th class="border border-gray-200 px-3 py-2 text-center text-xs font-medium text-gray-600 dark:border-gray-700 dark:text-gray-400">U</th>
                        <th class="border border-gray-200 px-3 py-2 text-center text-xs font-medium text-gray-600 dark:border-gray-700 dark:text-gray-400">R</th>
                        <th class="border border-gray-200 px-3 py-2 text-center text-xs font-medium text-purple-600 dark:border-gray-700">Dikti</th>
                    @endfor
                    <th class="border border-gray-200 bg-brand-50 px-3 py-2 text-center text-xs font-medium text-brand-600 dark:border-gray-700 dark:bg-brand-500/15">D</th>
                    <th class="border border-gray-200 bg-brand-50 px-3 py-2 text-center text-xs font-medium text-brand-600 dark:border-gray-700 dark:bg-brand-500/15">U</th>
                    <th class="border border-gray-200 bg-brand-50 px-3 py-2 text-center text-xs font-medium text-brand-600 dark:border-gray-700 dark:bg-brand-500/15">R</th>
                    <th class="border border-gray-200 bg-brand-50 px-3 py-2 text-center text-xs font-medium text-purple-600 dark:border-gray-700 dark:bg-brand-500/15">Dikti</th>
                </tr>
            </thead>
            <tbody>
                @php
                    $totalGel = [];
                    for ($i = 1; $i <= 10; $i++) { $totalGel[$i] = ['D' => 0, 'U' => 0, 'R' => 0, 'F' => 0]; }
                    $totalAll = ['D' => 0, 'U' => 0, 'R' => 0, 'F' => 0];
                @endphp
                @foreach ($prodi as $row)
                    @php
                        $totalD = 0; $totalU = 0; $totalR = 0; $totalF = 0;
                        for ($i = 1; $i <= 10; $i++) {
                            $d = $row->{'g'.$i.'_D'} ?? 0; $u = $row->{'g'.$i.'_U'} ?? 0;
                            $r = $row->{'g'.$i.'_R'} ?? 0; $f = $row->{'g'.$i.'_F'} ?? 0;
                            $totalD += $d; $totalU += $u; $totalR += $r; $totalF += $f;
                            $totalGel[$i]['D'] += $d; $totalGel[$i]['U'] += $u; $totalGel[$i]['R'] += $r; $totalGel[$i]['F'] += $f;
                        }
                        $totalAll['D'] += $totalD; $totalAll['U'] += $totalU; $totalAll['R'] += $totalR; $totalAll['F'] += $totalF;
                    @endphp
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                        <td class="border border-gray-200 px-4 py-3 text-sm font-medium text-gray-900 dark:border-gray-700 dark:text-white">{{ $row->nama_prodi }}</td>
                        @for ($i = 1; $i <= 10; $i++)
                            {{-- Kolom Diterima (D) --}}
                            <td class="border border-gray-200 px-3 py-2 text-center text-sm text-gray-700 dark:border-gray-700 dark:text-gray-300">
                                @if(($row->{'g'.$i.'_D'} ?? 0) > 0)
                                    <a href="javascript:void(0)" class="view-users-trigger text-blue-600 hover:underline font-medium" data-title="Mendaftar: Gel {{ $i }} - {{ $row->nama_prodi }}" data-users="{{ $row->{'g'.$i.'_D_users'} }}">{{ $row->{'g'.$i.'_D'} }}</a>
                                @else 0 @endif
                            </td>
                            {{-- Kolom Ujian (U) --}}
                            <td class="border border-gray-200 px-3 py-2 text-center text-sm text-gray-700 dark:border-gray-700 dark:text-gray-300">
                                @if(($row->{'g'.$i.'_U'} ?? 0) > 0)
                                    <a href="javascript:void(0)" class="view-users-trigger text-yellow-600 hover:underline font-medium" data-title="Mengikuti Ujian: Gel {{ $i }} - {{ $row->nama_prodi }}" data-users="{{ $row->{'g'.$i.'_U_users'} }}">{{ $row->{'g'.$i.'_U'} }}</a>
                                @else 0 @endif
                            </td>
                            {{-- Kolom Registrasi (R) --}}
                            <td class="border border-gray-200 px-3 py-2 text-center text-sm text-gray-700 dark:border-gray-700 dark:text-gray-300">
                                @if(($row->{'g'.$i.'_R'} ?? 0) > 0)
                                    <a href="javascript:void(0)" class="view-users-trigger text-green-600 hover:underline font-medium" data-title="Registrasi Ulang Paid: Gel {{ $i }} - {{ $row->nama_prodi }}" data-users="{{ $row->{'g'.$i.'_R_users'} }}">{{ $row->{'g'.$i.'_R'} }}</a>
                                @else 0 @endif
                            </td>
                            {{-- Kolom Final Data (F) --}}
                            <td class="border border-gray-200 px-3 py-2 text-center text-sm text-gray-700 dark:border-gray-700 dark:text-gray-300">
                                @if(($row->{'g'.$i.'_F'} ?? 0) > 0)
                                    <a href="javascript:void(0)" class="view-users-trigger text-purple-600 hover:underline font-medium" data-title="Data Final DIKTI: Gel {{ $i }} - {{ $row->nama_prodi }}" data-users="{{ $row->{'g'.$i.'_F_users'} }}">{{ $row->{'g'.$i.'_F'} }}</a>
                                @else 0 @endif
                            </td>
                        @endfor
                        <td class="border border-gray-200 px-3 py-2 text-center text-sm font-semibold text-brand-600 dark:border-gray-700 dark:bg-brand-500/10 dark:text-brand-400">{{ $totalD }}</td>
                        <td class="border border-gray-200 px-3 py-2 text-center text-sm font-semibold text-brand-600 dark:border-gray-700 dark:bg-brand-500/10 dark:text-brand-400">{{ $totalU }}</td>
                        <td class="border border-gray-200 px-3 py-2 text-center text-sm font-semibold text-brand-600 dark:border-gray-700 dark:bg-brand-500/10 dark:text-brand-400">{{ $totalR }}</td>
                        <td class="border border-gray-200 px-3 py-2 text-center text-sm font-semibold text-brand-600 dark:border-gray-700 dark:bg-brand-500/10 dark:text-brand-400">{{ $totalF }}</td>
                        @auth
                        <td class="border border-gray-200 px-3 py-2 text-center">
    <a href="{{ route('admin.show-all.export-prodi', urlencode($row->nama_prodi)) }}"
       class="inline-flex items-center gap-1 rounded-lg bg-brand-500 px-3 py-1.5 text-xs font-medium text-white hover:bg-brand-600 transition-all">
        <i class="fas fa-download"></i> Unduh
    </a>
</td>
@endauth
                    </tr>
                @endforeach
                {{-- GRAND TOTAL --}}
                <tr class="bg-brand-100 dark:bg-brand-500/20">
                    <td class="border border-gray-200 px-4 py-3 text-sm font-bold text-gray-900 dark:border-gray-700 dark:text-white">GRAND TOTAL</td>
                    @for ($i = 1; $i <= 10; $i++)
                        <td class="border border-gray-200 px-3 py-2 text-center text-sm font-bold text-gray-900 dark:border-gray-700 dark:text-white">{{ $totalGel[$i]['D'] }}</td>
                        <td class="border border-gray-200 px-3 py-2 text-center text-sm font-bold text-gray-900 dark:border-gray-700 dark:text-white">{{ $totalGel[$i]['U'] }}</td>
                        <td class="border border-gray-200 px-3 py-2 text-center text-sm font-bold text-gray-900 dark:border-gray-700 dark:text-white">{{ $totalGel[$i]['R'] }}</td>
                        <td class="border border-gray-200 px-3 py-2 text-center text-sm font-bold text-gray-900 dark:border-gray-700 dark:text-white">{{ $totalGel[$i]['F'] }}</td>
                    @endfor
                    <td class="border border-gray-200 bg-brand-500 px-3 py-2 text-center text-sm font-bold text-white">{{ $totalAll['D'] }}</td>
                    <td class="border border-gray-200 bg-brand-500 px-3 py-2 text-center text-sm font-bold text-white">{{ $totalAll['U'] }}</td>
                    <td class="border border-gray-200 bg-brand-500 px-3 py-2 text-center text-sm font-bold text-white">{{ $totalAll['R'] }}</td>
                    <td class="border border-gray-200 bg-brand-500 px-3 py-2 text-center text-sm font-bold text-white">{{ $totalAll['F'] }}</td>
                    <td class="border border-gray-200 bg-brand-100 dark:bg-brand-500/20"></td>
                </tr>
            </tbody>
        </table>
    </div>


</div>

{{-- TABEL REKAP BIODATA & JALUR PENDAFTARAN --}}
<div class="mt-6 rounded-lg bg-white p-6 shadow-theme-sm dark:bg-gray-dark" x-data="rekapGrafik()">
    <div class="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h2 class="text-title-md font-bold text-gray-900 dark:text-white">
                Grafik Analisis Mahasiswa (Saat Ini)
            </h2>
            <p class="text-sm text-gray-500">Distribusi pendaftar per gelombang berdasarkan kategori</p>
        </div>

        <div class="flex items-center gap-3">
            <label class="text-sm font-medium text-gray-700 dark:text-gray-300">Filter:</label>
            <select 
                x-model="selectedCategory" 
                @change="updateChart()"
                class="rounded-lg border border-gray-300 bg-gray-50 px-4 py-2 text-sm focus:border-brand-500 focus:ring-brand-500 dark:border-gray-700 dark:bg-gray-900"
            >
                <template x-for="cat in categories" :key="cat">
                    <option :value="cat" x-text="cat"></option>
                </template>
            </select>
        </div>
    </div>

    <div class="min-h-[400px] w-full" id="chart-rekap"></div>

    <div class="mt-8 overflow-x-auto">
        <h3 class="mb-3 text-sm font-bold uppercase tracking-wider text-gray-500">Data Tabulasi: <span x-text="selectedCategory" class="text-brand-500"></span></h3>
        <table class="min-w-full border-collapse text-xs">
            <thead>
                <tr class="bg-gray-100 dark:bg-gray-800">
                    <th class="border border-gray-200 p-2 text-left dark:border-gray-700">Item</th>
                    @for ($g = 1; $g <= 10; $g++)
                        <th class="border border-gray-200 p-2 text-center dark:border-gray-700">G{{ $g }}</th>
                    @endfor
                    <th class="border border-gray-200 bg-brand-50 p-2 text-center font-bold text-brand-600 dark:border-gray-700">Total</th>
                </tr>
            </thead>
            <tbody>
                <template x-for="row in filteredData" :key="row.nama">
                    <tr class="hover:bg-gray-50 dark:hover:bg-gray-800/50">
                        <td class="border border-gray-200 p-2 font-medium dark:border-gray-700" x-text="row.nama"></td>
                        <template x-for="g in [1,2,3,4,5,6,7,8,9,10]" :key="g">
                            <td class="border border-gray-200 p-2 text-center dark:border-gray-700" x-text="row['g'+g] || 0"></td>
                        </template>
                        <td class="border border-gray-200 bg-brand-50/30 p-2 text-center font-bold dark:border-gray-700" x-text="calculateTotal(row)"></td>
                    </tr>
                </template>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

<script>


    // =========================================================
    // 2. SCRIPT UNTUK GRAFIK ANALISIS SAAT INI (KODE ASLI MU)
    // =========================================================
    function rekapGrafik() {
        const rawData = @json($rekap);
        return {
            selectedCategory: 'Asal Wilayah', 
            categories: [...new Set(rawData.map(item => item.category_type))],
            chart: null,
            get filteredData() { return rawData.filter(item => item.category_type === this.selectedCategory); },
            calculateTotal(row) {
                let total = 0;
                for(let i=1; i<=10; i++) total += parseInt(row['g'+i] || 0);
                return total;
            },
            init() { this.$nextTick(() => { this.renderChart(); }); },
            renderChart() {
                const options = {
                    series: this.getSeries(),
                    chart: { type: 'bar', height: 400, stacked: true, toolbar: { show: true }, fontFamily: 'Inter, sans-serif' },
                    plotOptions: { bar: { horizontal: false, columnWidth: '55%', borderRadius: 4 } },
                    dataLabels: { enabled: false },
                    stroke: { show: true, width: 2, colors: ['transparent'] },
                    xaxis: { categories: ['Gel 1', 'Gel 2', 'Gel 3', 'Gel 4', 'Gel 5', 'Gel 6', 'Gel 7', 'Gel 8', 'Gel 9', 'Gel 10'] },
                    yaxis: { title: { text: 'Jumlah Mahasiswa' } },
                    fill: { opacity: 1 },
                    colors: ['#3C50E0', '#80CAEE', '#10B981', '#FF9C55', '#FF5B5B'],
                    legend: { position: 'top', horizontalAlign: 'left' }
                };
                this.chart = new ApexCharts(document.querySelector("#chart-rekap"), options);
                this.chart.render();
            },
            getSeries() {
                return this.filteredData.map(item => {
                    const dataPoints = [];
                    for(let i=1; i<=10; i++) { dataPoints.push(parseInt(item['g'+i] || 0)); }
                    return { name: item.nama, data: dataPoints };
                });
            },
            updateChart() { this.chart.updateSeries(this.getSeries()); }
        }
    }
</script>

{{-- SECTION GRAFIK ANALISIS KATEGORI (CHART.JS) --}}
<div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
    @php
        $groupedRekap = $rekap->groupBy('category_type');
    @endphp

    @foreach($groupedRekap as $type => $items)
    <div class="rounded-lg bg-white p-6 shadow-theme-sm dark:bg-gray-dark">
        <h3 class="mb-4 text-lg font-bold text-gray-900 dark:text-white">Analisis {{ $type }}</h3>
        <div class="h-80">
            <canvas id="chart_{{ Str::slug($type) }}"></canvas>
        </div>
    </div>
    @endforeach
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const colors = [
            'rgba(59, 130, 246, 0.8)', 'rgba(249, 115, 22, 0.8)', 
            'rgba(16, 185, 129, 0.8)', 'rgba(139, 92, 246, 0.8)',
            'rgba(236, 72, 153, 0.8)'
        ];

        @foreach($groupedRekap as $type => $items)
        new Chart(document.getElementById('chart_{{ Str::slug($type) }}').getContext('2d'), {
            type: 'bar',
            data: {
                labels: ['Gel 1', 'Gel 2', 'Gel 3', 'Gel 4', 'Gel 5', 'Gel 6', 'Gel 7', 'Gel 8', 'Gel 9', 'Gel 10'],
                datasets: [
                    @foreach($items as $index => $row)
                    {
                        label: '{{ $row->nama }}',
                        data: [
                            {{ $row->g1 }}, {{ $row->g2 }}, {{ $row->g3 }}, {{ $row->g4 }}, 
                            {{ $row->g5 }}, {{ $row->g6 }}, {{ $row->g7 }}, {{ $row->g8 }}, 
                            {{ $row->g9 }}, {{ $row->g10 }}
                        ],
                        backgroundColor: colors[{{ $index }} % colors.length],
                    },
                    @endforeach
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { boxWidth: 12, usePointStyle: true } },
                    tooltip: { mode: 'index', intersect: false }
                },
                scales: {
                    x: { stacked: true },
                    y: { stacked: true, beginAtZero: true }
                }
            }
        });
        @endforeach
    });
</script>

<div class="modal fade fixed inset-0 z-9999 hidden w-full h-full outline-none overflow-x-hidden overflow-y-auto bg-black/50 backdrop-blur-sm flex items-center justify-center p-4" id="userListModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="relative w-full max-w-md pointer-events-none">
        <div class="relative flex flex-col w-full pointer-events-auto bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl shadow-2xl outline-none">
            
            <div class="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800">
                <h5 class="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2" id="modalTargetTitle">
                    <i class="fas fa-users text-brand-500"></i> Detail Mahasiswa
                </h5>
                <button type="button" class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 text-lg p-1" onclick="$('#userListModal').addClass('hidden').removeClass('flex')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="p-5 max-h-[380px] overflow-y-auto">
                <ol id="userListContainer" class="list-decimal pl-5 space-y-2.5 text-sm text-gray-700 dark:text-gray-300 font-medium tracking-wide"></ol>
            </div>
            
            <div class="flex items-center justify-end p-3 border-t border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900/50 rounded-b-xl">
                <button type="button" class="px-4 py-2 text-xs font-semibold text-gray-600 bg-white border border-gray-300 rounded-lg hover:bg-gray-100 dark:bg-gray-800 dark:text-gray-400 dark:border-gray-700 dark:hover:bg-gray-700" onclick="$('#userListModal').addClass('hidden').removeClass('flex')">Tutup</button>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        // Event click pemicu popup nama mahasiswa
        $('.view-users-trigger').on('click', function() {
            var title = $(this).data('title');
            var rawUsers = $(this).data('users'); 
            
            $('#modalTargetTitle').html('<i class="fas fa-users text-blue-500"></i> ' + title);
            var container = $('#userListContainer');
            container.empty();
            
            if (rawUsers && rawUsers.trim() !== "") {
                var userArray = rawUsers.split('||');
                userArray.forEach(function(user) {
                    container.append('<li class="border-b border-gray-100 dark:border-gray-800/40 pb-1.5 last:border-0">' + user + '</li>');
                });
            } else {
                container.append('<li class="text-muted list-none text-center py-4 text-gray-400">Tidak ada rekam riwayat user pada data ini.</li>');
            }
            
            // Tampilkan modal container menggunakan utility flex
            $('#userListModal').removeClass('hidden').addClass('flex');
        });

        // Menutup modal jika admin klik di luar box putih modal
        $('#userListModal').on('click', function(e) {
            if (e.target === this) {
                $(this).addClass('hidden').removeClass('flex');
            }
        });
    });
</script>

@endsection