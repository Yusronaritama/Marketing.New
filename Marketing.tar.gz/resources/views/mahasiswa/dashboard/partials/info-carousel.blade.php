{{-- ========================================== --}}
{{-- 1. CEK KUOTA WIDGET (MATCHING SIZE)        --}}
{{-- ========================================== --}}
@php
    $majorsData = \App\Models\ProgramStudi::query()
                    ->where('status_prodi', 1) // Ambil yang statusnya Aktif
                    ->orderBy('jenjang', 'asc')
                    ->orderBy('nama_prodi', 'asc')
                    ->get()
                    ->map(function($prodi) {
                        return [
                            'id' => $prodi->kode_prodi,
                            'nama' => $prodi->nama_prodi,
                            'jenjang' => $prodi->jenjang,
                            
                            // [PERBAIKAN] Langsung panggil kolom 'kuota' dari database
                            // Jika null, anggap 0. Jika angka aneh (>9000), anggap Unlimited.
                            'sisa' => ($prodi->kuota ?? 0) > 9000 ? '∞' : ($prodi->kuota ?? 0),
                            
                            // Hitung Persen Manual biar tidak error aksesoria
                            'persen' => ($prodi->daya_tampung > 0) 
                                        ? round(($prodi->jumlah_pendaftar / $prodi->daya_tampung) * 100, 1) 
                                        : 0
                        ];
                    })
                    ->values(); 
@endphp

<div class="w-full mb-6"
     x-data='{
        expanded: false,
        selected: "", 
        majors: @json($majorsData),
        get current() {
            return this.majors.find(m => m.id == this.selected);
        }
     }'>

    {{-- A. TRIGGER BUTTON (SIZE: MATCH WAVE MONITOR) --}}
    {{-- Menggunakan p-4 (bukan p-3.5) agar tinggi tombol sama --}}
    <button @click="expanded = !expanded" 
            class="relative w-full flex items-center justify-between bg-white border border-gray-200 rounded-xl p-4 shadow-sm hover:shadow-md hover:border-indigo-300 transition-all duration-300 group overflow-hidden">
        
        <div class="absolute inset-0 bg-blue-50/50 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-500"></div>

        <div class="relative z-10 flex items-center gap-4">
            {{-- Icon Box: w-10 h-10 (Sama dengan Wave Monitor) --}}
            <div class="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center text-blue-600 shadow-sm group-hover:scale-110 transition-transform">
                <i class="fas fa-search-location text-lg"></i>
            </div>
            
            <div class="text-left">
                <div class="flex items-center gap-2">
                    <span class="text-[9px] font-mono font-bold uppercase tracking-widest text-gray-500">Database Query</span>
                    <span class="flex h-2 w-2 relative">
                        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                        <span class="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                    </span>
                </div>
                {{-- Text Size: text-sm (Sama dengan Wave Monitor) --}}
                <h3 class="font-bold text-gray-800 text-sm uppercase tracking-tight">Cek Kuota Jurusan</h3>
            </div>
        </div>

        {{-- Arrow: w-8 h-8 (Sama dengan Wave Monitor) --}}
        <div class="relative z-10 w-8 h-8 rounded-full border border-gray-100 flex items-center justify-center text-gray-400 transition-transform duration-300 bg-white"
             :class="expanded ? 'rotate-180 bg-blue-50 text-blue-600 border-blue-200' : ''">
            <i class="fas fa-chevron-down text-xs"></i>
        </div>
    </button>

    {{-- B. EXPANDABLE CONTENT --}}
    <div x-show="expanded" x-collapse x-cloak>
        <div class="mt-2 bg-gray-50/90 border border-gray-200 rounded-xl shadow-inner overflow-hidden relative backdrop-blur-sm">
            
            <div class="relative z-10 p-4"> {{-- Padding p-4 agar proporsional --}}
                
                {{-- 1. Input Search --}}
                <div class="mb-4">
                    <div class="relative">
                        <select x-model="selected" 
                                class="w-full appearance-none rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-xs font-bold text-gray-700 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 transition-all cursor-pointer font-mono uppercase">
                            <option value="" disabled selected>-- PILIH JURUSAN --</option>
                            <template x-for="major in majors" :key="major.id">
                                <option :value="major.id" x-text="'[' + major.jenjang + '] ' + major.nama"></option>
                            </template>
                        </select>
                        <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-gray-400">
                            <i class="fas fa-caret-down text-xs"></i>
                        </div>
                    </div>
                </div>

                {{-- 2. Result Display Area (FIXED HEIGHT STABLE) --}}
                <div class="min-h-[140px] bg-white rounded-lg border border-gray-200 p-3 relative overflow-hidden shadow-sm flex flex-col justify-center">
                    
                    {{-- STATE 1: IDLE --}}
                    <div x-show="!selected" class="flex flex-col items-center justify-center h-full text-center absolute inset-0">
                        <i class="fas fa-university text-gray-300 text-2xl mb-1 animate-bounce"></i>
                        <p class="text-[9px] font-mono text-gray-400 uppercase tracking-widest">Silakan pilih jurusan...</p>
                    </div>

                    {{-- STATE 2: RESULT --}}
                    <div x-show="selected" 
                         x-transition:enter="transition ease-out duration-300"
                         x-transition:enter-start="opacity-0 translate-y-2"
                         x-transition:enter-end="opacity-100 translate-y-0"
                         class="w-full h-full flex flex-col justify-between"
                         style="display: none;">
                        
                        {{-- Header Info --}}
                        <div class="flex justify-between items-start mb-2 border-b border-gray-100 pb-2">
                            <div class="w-full">
                                <div class="flex items-center gap-2 mb-1">
                                    <span class="text-[8px] font-bold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100" x-text="current?.jenjang"></span>
                                    <span class="text-[8px] font-mono text-gray-400" x-text="'ID:' + current?.id"></span>
                                </div>
                                <h4 class="text-xs font-bold text-gray-800 uppercase tracking-wide leading-tight line-clamp-1" x-text="current?.nama"></h4>
                            </div>
                        </div>

                        {{-- Stats Grid --}}
                        <div class="grid grid-cols-2 gap-3 mb-3">
                            {{-- Sisa Kuota --}}
                            <div class="bg-gray-50 rounded p-2 border border-gray-200 text-center">
                                <span class="block text-[7px] text-gray-500 uppercase tracking-wider font-mono">Available</span>
                                <span class="block text-xl font-mono font-black text-blue-600 leading-none mt-0.5" x-text="current?.sisa"></span>
                            </div>
                            {{-- Persentase --}}
                            <div class="bg-gray-50 rounded p-2 border border-gray-200 text-center">
                                <span class="block text-[7px] text-gray-500 uppercase tracking-wider font-mono">Filled</span>
                                <span class="block text-xl font-mono font-black text-gray-700 leading-none mt-0.5" x-text="current?.persen + '%'"></span>
                            </div>
                        </div>

                        {{-- Progress Bar --}}
                        <div>
                            <div class="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
                                <div class="bg-gradient-to-r from-blue-500 to-indigo-500 h-full rounded-full transition-all duration-1000 shadow-sm" 
                                     :style="'width: ' + (current ? current.persen : 0) + '%'"></div>
                            </div>
                        </div>

                    </div>
                </div>

                {{-- Footer Info --}}
                <div class="mt-3 flex items-center gap-1.5 justify-center opacity-75">
                    <i class="fas fa-sync-alt text-gray-400 text-[8px]"></i>
                    <p class="text-[8px] text-gray-500 font-mono">
                        Real-time Data Sync.
                    </p>
                </div>

            </div>
        </div>
    </div>
</div>