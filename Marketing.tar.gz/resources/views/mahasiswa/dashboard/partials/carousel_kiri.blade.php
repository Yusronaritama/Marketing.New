{{-- ========================================== --}}
{{-- 2. WAVE MONITOR (EXPANDABLE LIGHT THEME)   --}}
{{-- ========================================== --}}
<div class="w-full relative z-20" {{-- Tambah relative z-20 agar tooltip muncul di atas elemen lain --}}
     id="wave-monitor-widget"     {{-- Tambah ID untuk target scroll (opsional tapi bagus) --}}
     x-data="{
        expanded: false,
        wave: 0,
        monthName: '',
        startDate: '',
        endDate: '',
        progress: 0,
        isOpen: true,
        daysLeft: 0,
        statusText: '',
        
        // --- [BARU] STATE UNTUK HINT ---
        showHint: false, 

        // DATA DARI CONTROLLER
        groupList: {{ $listGroupWA->toJson() }},
        
        // VARIABLE GROUP WA
        currentLink: '',
        currentName: '',
        currentDesc: '',

        init() {
            const now = new Date();
            let year = now.getFullYear();
            const monthIndex = now.getMonth(); // 0 = Jan, 11 = Dec
            const today = now.getDate();

            this.monthName = now.toLocaleDateString('id-ID', { month: 'long' });

            // LOGIKA BARU: GELOMBANG 1 (DESEMBER - JANUARI)
            if (monthIndex === 11 || monthIndex === 0) { 
                this.isOpen = true;
                this.wave = 1;
                this.statusText = 'SYSTEM ACTIVE (LONG WAVE)';

                let startYear = (monthIndex === 11) ? year : year - 1;
                let endYear = (monthIndex === 11) ? year + 1 : year;

                const wave1Start = new Date(startYear, 11, 11); 
                const wave1End = new Date(endYear, 0, 31); 

                const totalDuration = wave1End - wave1Start;
                const elapsedTime = now - wave1Start;
                const diffTime = wave1End - now;
                this.daysLeft = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

                let pct = Math.round((elapsedTime / totalDuration) * 100);
                this.progress = Math.max(0, Math.min(100, pct));

                this.startDate = wave1Start.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: '2-digit' }).toUpperCase();
                this.endDate = wave1End.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: '2-digit' }).toUpperCase();

            } else if (monthIndex === 10) { 
                this.isOpen = false;
                this.wave = '-';
                this.statusText = 'SYSTEM OFFLINE';
                
                const nextOpen = new Date(year, 11, 11);
                this.startDate = 'CLOSED';
                this.endDate = 'NEXT: 11 DEC';
                
                const diffTime = Math.abs(nextOpen - now);
                this.daysLeft = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                this.progress = 100;
            } else {
                this.isOpen = true;
                this.wave = monthIndex + 1; 
                this.statusText = 'SYSTEM ACTIVE';
                const firstDay = new Date(year, monthIndex, 1);
                const lastDay = new Date(year, monthIndex + 1, 0); 
                const totalDays = lastDay.getDate();

                this.startDate = firstDay.toLocaleDateString('id-ID', { day: '2-digit', month: 'short' }).toUpperCase();
                this.endDate = lastDay.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: '2-digit' }).toUpperCase();
                
                this.daysLeft = totalDays - today;
                this.progress = Math.round((today / totalDays) * 100);
            }

            // CARI GROUP WA BERDASARKAN WAVE
            let foundGroup = this.groupList.find(g => g.gelombang == this.wave);
            if (foundGroup) {
                this.currentLink = foundGroup.link_group;
                this.currentName = foundGroup.nama_gelombang;
                this.currentDesc = foundGroup.deskripsi || 'Official Candidate Group';
            }
        }
     }"
     x-init="init()"
     
     {{-- [BARU] EVENT LISTENER UNTUK MENANGKAP SINYAL HINT DARI DASHBOARD --}}
     x-on:show-wa-hint.window="
        $el.scrollIntoView({ behavior: 'smooth', block: 'center' }); // Scroll otomatis ke widget ini
        showHint = true;  // Munculkan tooltip
        expanded = true;  // Buka accordion otomatis
        setTimeout(() => showHint = false, 5000); // Hilangkan tooltip setelah 5 detik
     ">
     
    {{-- [BARU] KOMPONEN TOOLTIP (MUNCUL DI ATAS TOMBOL) --}}
    <div x-show="showHint"
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0 translate-y-4"
         x-transition:enter-end="opacity-100 translate-y-0"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         class="absolute -top-14 left-0 right-0 flex justify-center z-50 pointer-events-none">
        
        <div class="bg-emerald-600 text-white text-xs font-bold py-2 px-4 rounded-full shadow-lg shadow-emerald-200/50 flex items-center gap-2 animate-bounce">
            <i class="fab fa-whatsapp text-lg"></i>
            <span>Link Grup WA ada di sini ya!</span>
            {{-- Panah Kecil Bawah --}}
            <div class="absolute -bottom-1 left-1/2 -translate-x-1/2 w-3 h-3 bg-emerald-600 rotate-45"></div>
        </div>
    </div>

    {{-- A. TRIGGER BUTTON (TEMA TERANG) --}}
    <button @click="expanded = !expanded" 
            class="relative w-full flex items-center justify-between bg-white border rounded-xl p-4 shadow-sm hover:shadow-md hover:border-indigo-300 transition-all duration-300 group overflow-hidden"
            {{-- [BARU] BORDER AKAN BERUBAH JADI HIJAU JIKA HINT AKTIF --}}
            :class="showHint ? 'border-emerald-500 ring-4 ring-emerald-100' : 'border-gray-200'">
        
        <div class="absolute inset-0 bg-indigo-50/50 transform scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-500"></div>

        <div class="relative z-10 flex items-center gap-4">
            <div class="w-10 h-10 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-600 shadow-sm group-hover:scale-110 transition-transform">
                <i class="fas fa-broadcast-tower text-lg"></i>
            </div>
            
            <div class="text-left">
                <div class="flex items-center gap-2">
                    <span class="text-[9px] font-mono font-bold uppercase tracking-widest text-gray-500">Wave Monitor</span>
                    <span class="flex h-2 w-2 relative">
                        <span class="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75" :class="isOpen ? 'bg-green-400' : 'bg-red-400'"></span>
                        <span class="relative inline-flex rounded-full h-2 w-2" :class="isOpen ? 'bg-green-500' : 'bg-red-500'"></span>
                    </span>
                </div>
                <h3 class="font-bold text-gray-800 text-sm uppercase tracking-tight">Status Gelombang <span x-text="wave"></span></h3>
            </div>
        </div>

        <div class="relative z-10 w-8 h-8 rounded-full border border-gray-100 flex items-center justify-center text-gray-400 transition-transform duration-300 bg-white"
             :class="expanded ? 'rotate-180 bg-indigo-50 text-indigo-600 border-indigo-200' : ''">
            <i class="fas fa-chevron-down text-xs"></i>
        </div>
    </button>

    {{-- B. EXPANDABLE CONTENT --}}
    <div x-show="expanded" x-collapse x-cloak>
        <div class="mt-2 bg-gray-50/95 border border-gray-200 rounded-xl shadow-inner overflow-hidden relative backdrop-blur-sm">
            <div class="absolute inset-0 opacity-[0.03]" style="background-image: linear-gradient(#000 1px, transparent 1px); background-size: 20px 20px;"></div>

            <div class="relative z-10 p-5">
                <div class="flex justify-between items-center mb-5 border-b border-gray-200/60 pb-4">
                    <div>
                        <span class="text-[10px] font-mono text-gray-500 uppercase">Current Phase</span>
                        <div class="text-xl font-black text-gray-900 tracking-widest uppercase">
                            GELOMBANG <span class="text-indigo-600" x-text="wave"></span>
                        </div>
                    </div>
                    <div class="px-2 py-1 rounded border backdrop-blur-sm shadow-sm"
                         :class="isOpen ? 'bg-green-100 border-green-200 text-green-700' : 'bg-red-100 border-red-200 text-red-700'">
                        <span class="text-[10px] font-bold font-mono uppercase tracking-wide flex items-center gap-1">
                            <i class="fas" :class="isOpen ? 'fa-satellite' : 'fa-ban'"></i>
                            <span x-text="statusText"></span>
                        </span>
                    </div>
                </div>

                <div class="grid grid-cols-3 gap-3 mb-5 text-center">
                    <div class="bg-white rounded-xl p-3 border border-gray-200 shadow-sm">
                        <span class="block text-[8px] text-gray-500 uppercase font-mono">Start</span>
                        <span class="block text-xs font-bold text-gray-900" x-text="startDate"></span>
                    </div>
                    <div class="bg-white rounded-xl p-3 border border-gray-200 shadow-sm">
                        <span class="block text-[8px] text-gray-500 uppercase font-mono">End</span>
                        <span class="block text-xs font-bold text-gray-900" x-text="endDate"></span>
                    </div>
                    <div class="bg-white rounded-xl p-3 border border-gray-200 shadow-sm">
                        <span class="block text-[8px] text-gray-500 uppercase font-mono">Remaining</span>
                        <span class="block text-xs font-bold text-indigo-600" x-text="daysLeft + ' DAYS'"></span>
                    </div>
                </div>

                <div class="mb-6">
                    <div class="flex justify-between text-[9px] text-gray-500 mb-1 font-mono">
                        <span>TIMELINE</span>
                        <span x-text="progress + '%'"></span>
                    </div>
                    <div class="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                        <div class="h-full rounded-full transition-all duration-1000"
                             :class="isOpen ? 'bg-gradient-to-r from-indigo-500 to-indigo-600' : 'bg-red-500'"
                             :style="'width: ' + progress + '%'"></div>
                    </div>
                </div>

                {{-- [MODIF] LINK GROUP WA DENGAN EFEK HIGHLIGHT JIKA HINT AKTIF --}}
                <template x-if="currentLink">
                    <a :href="currentLink" target="_blank" 
                       class="flex items-center justify-between bg-white border border-green-200 rounded-lg p-3 shadow-sm hover:shadow-md hover:border-green-300 transition-all group"
                       :class="showHint ? 'animate-pulse ring-2 ring-green-300' : ''"> {{-- Efek kedip di link jika hint aktif --}}
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded bg-green-100 flex items-center justify-center text-green-600 border border-green-200">
                                <i class="fab fa-whatsapp"></i>
                            </div>
                            <div class="overflow-hidden">
                                <div class="text-[9px] font-mono text-green-600/70 uppercase">Secure Channel</div>
                                <div class="text-xs font-bold text-gray-900 truncate w-32" x-text="currentName"></div>
                            </div>
                        </div>
                        <i class="fas fa-external-link-alt text-green-500 text-xs group-hover:translate-x-1 transition-transform"></i>
                    </a>
                </template>

                <div class="mt-3 text-center">
                    <p class="text-[9px] text-gray-500 font-mono">
                        System Cycle: 10 Waves (Dec - Oct)
                    </p>
                </div>

            </div>
        </div>
    </div>
</div>