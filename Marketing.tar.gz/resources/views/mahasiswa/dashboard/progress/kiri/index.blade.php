{{-- FILE: resources/views/mahasiswa/dashboard/progress-layouts.blade.php --}}

@php
    // --- 1. LOGIKA STATUS PER STEP ---
    
    // Step 1: Akun Pendaftar (Selalu Completed karena sudah login)
    $s1_status = 'completed';

    // Step 2: Biodata
    $s2_status = $biodataSelesai ? 'completed' : 'active';

    // Step 3: Ujian Seleksi
    $eregSelesai = $ereg && ($ereg->status == 'completed' || $ereg->status == 'final');
    $s3_status = 'pending';
    if ($s2_status == 'completed') {
        if ($eregSelesai && $isUjianSelesai) {
            $s3_status = 'completed';
        } elseif ($eregSelesai) {
            $s3_status = 'active';
        } else {
            $s3_status = 'pending';
        }
    }

    // Step 4: Pembayaran UKT
    $s4_status = 'pending';
    if ($s3_status == 'completed') {
        if ($isBayarLunas) {
            $s4_status = 'completed';
        } elseif ($statusKelulusan == 'LULUS') {
            $s4_status = 'active';
        }
    }

    // Step 5: Data Final (Pelaporan PDDIKTI)
    $s5_status = 'pending';
    if ($s4_status == 'completed') {
        if (isset($isDataFinalAdaDiDB) && $isDataFinalAdaDiDB) {
            $s5_status = 'completed';
        } else {
            $s5_status = 'active';
        }
    }

    // Step 6: Portal Mahasiswa (Generate NIM & Akun)
    $s6_status = 'pending';
    if ($s5_status == 'completed') {
        // Jika NIM sudah ada di tabel pendaftar_get_nim, maka Step 6 dianggap Selesai (100%)
        if (isset($akunSudahAda) && $akunSudahAda) {
            $s6_status = 'completed'; 
        } else {
            $s6_status = 'active'; // Menunggu antrean generate NIM
        }
    }

    // --- 2. DATA ARRAY STEPS UNTUK LOOPING UI ---
    $steps = [
        1 => ['label' => 'Akun', 'id' => 'ACC-01', 'icon' => 'user-check', 'status' => $s1_status],
        2 => ['label' => 'Biodata', 'id' => 'BIO-02', 'icon' => 'fingerprint', 'status' => $s2_status],
        3 => ['label' => 'Ujian', 'id' => 'CBT-03', 'icon' => 'laptop-code', 'status' => $s3_status],
        4 => ['label' => 'Bayar', 'id' => 'PAY-04', 'icon' => 'credit-card', 'status' => $s4_status],
        5 => ['label' => 'Final', 'id' => 'FIN-05', 'icon' => 'server', 'status' => $s5_status],
        6 => ['label' => 'Informasi PKKMB', 'id' => 'SYS-06', 'icon' => 'bullhorn', 'status' => $s6_status],
    ];

    // --- 3. PERHITUNGAN PERSENTASE ---
    $completedCount = 0;
    foreach($steps as $s) {
        if($s['status'] == 'completed') $completedCount++;
    }
    $percentage = round(($completedCount / 6) * 100);

    // --- 4. LABEL STATUS UTAMA (SYSTEM MESSAGES) ---
    $mainStatus = 'System Standby';
    if($percentage >= 100) {
        $mainStatus = 'Registration Accomplished'; 
    } elseif($percentage >= 80) {
        $mainStatus = 'Finalizing';
    } elseif($percentage >= 50) {
        $mainStatus = 'Processing';
    } elseif($percentage > 0) {
        $mainStatus = 'Initializing';
    }
    
    // --- 5. LOGIKA DISPLAY RANK / STATUS KELULUSAN ---
    $rankTitle = 'STATUS SELEKSI';
    $rankSubtitle = '-'; 
    $rankIcon = 'circle-notch'; 
    $rankTheme = 'slate'; 
    $isContentHidden = false;

    if ($statusKelulusan == 'LULUS') {
        if ($isBayarLunas) {
            // Lulus & Sudah Bayar
            $rankTitle = 'LULUS SELEKSI';
            $rankSubtitle = $jurusanDiterima;
            $rankIcon = 'graduation-cap';
            $rankTheme = 'emerald'; 
        } else {
            // Lulus tapi belum bayar (Data detail disembunyikan/dikunci)
            $rankTitle = 'Selesaikan Administrasi';
            $rankSubtitle = 'Selesaikan Pembayaran';
            $rankIcon = 'lock';
            $isContentHidden = true; 
        }
    } elseif ($statusKelulusan == 'TIDAK_LULUS') {
        // Tidak Lulus
        $rankTitle = 'TIDAK LULUS';
        $rankSubtitle = 'Mohon Maaf';
        $rankIcon = 'times-circle';
        $rankTheme = 'red';
    }
@endphp

{{-- MAIN CONTAINER --}}
<div id="tour-progress-bar" class="w-full max-w-5xl mx-auto bg-blue-600/10 backdrop-blur-xl border border-blue-200/30 rounded-3xl shadow-xl shadow-blue-500/10 p-6 lg:p-8 relative overflow-hidden group transition-all duration-700 ease-out transform opacity-0 scale-95"
     x-data="{
        mounted: false,
        targetPercent: {{ $percentage }},
        currentPercent: 0,
        circumference: 283, 
        
        init() {
            setTimeout(() => { 
                this.mounted = true; 
                $el.classList.remove('opacity-0', 'scale-95');
                $el.classList.add('opacity-100', 'scale-100');
            }, 100);

            setTimeout(() => {
                let interval = setInterval(() => {
                    if (this.currentPercent < this.targetPercent) {
                        this.currentPercent++;
                    } else {
                        clearInterval(interval);
                    }
                }, 20);
            }, 500);
        }
     }"
     x-init="init()">
    
    {{-- Background Tech Grid Pattern --}}
    <div class="absolute inset-0 opacity-[0.05]"
         style="background-image: radial-gradient(#3b82f6 1px, transparent 1px); background-size: 20px 20px;"></div>

    {{-- ================================================= --}}
    {{-- MOBILE VIEW (LIST INTERAKTIF)                     --}}
    {{-- ================================================= --}}
    <div class="block md:hidden relative z-10">
        
        {{-- HEADER RINGKASAN --}}
        <div class="flex items-center justify-between mb-8 pb-4 border-b border-blue-100/20">
            <div>
                <h3 class="font-bold text-lg text-slate-800">Status Pendaftaran</h3>
                <div class="flex items-center gap-2 mt-1">
                    <span class="relative flex h-2 w-2">
                        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                        <span class="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                    </span>
                    <p class="text-xs font-mono text-slate-600 uppercase">{{ $mainStatus }}</p>
                </div>
            </div>
            {{-- Circular Progress Kecil di Kanan --}}
            <div class="relative w-12 h-12 flex items-center justify-center">
                <svg class="w-full h-full transform -rotate-90">
                    <circle cx="50%" cy="50%" r="20" fill="none" stroke="#e2e8f0" stroke-width="4" />
                    <circle cx="50%" cy="50%" r="20" fill="none" stroke="#3b82f6" stroke-width="4" stroke-linecap="round" stroke-dasharray="125" :stroke-dashoffset="125 - (currentPercent / 100 * 125)" class="transition-all duration-1000 ease-out" />
                </svg>
                <span class="absolute text-[10px] font-bold text-blue-600"><span x-text="currentPercent"></span>%</span>
            </div>
        </div>

        {{-- TIMELINE CONTAINER --}}
        <div class="relative pl-4 space-y-8">
            
            {{-- GARIS PENGHUBUNG VERTIKAL (Background Line) --}}
            <div class="absolute left-[27px] top-2 bottom-4 w-0.5 bg-slate-200"></div>

            @foreach($steps as $num => $item)
                @php
                    $isDone = $item['status'] == 'completed';
                    $isActive = $item['status'] == 'active';
                @endphp

                <div id="nav-mobile-step-{{ $num }}" 
                     @click="activeView = {{ $num }}; window.scrollTo({ top: 0, behavior: 'smooth' })"
                     class="relative flex items-start gap-4 cursor-pointer group"
                     x-show="mounted"
                     x-transition:enter="transition ease-out duration-500"
                     x-transition:enter-start="opacity-0 translate-x-4"
                     x-transition:enter-end="opacity-100 translate-x-0"
                     style="transition-delay: {{ $num * 100 }}ms;">
                    
                    {{-- BULATAN INDIKATOR (Marker) --}}
                    <div class="relative z-10 flex-shrink-0 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-300 bg-white
                                {{ $isDone ? 'border-emerald-500 bg-emerald-50' : ($isActive ? 'border-blue-500 bg-blue-50 shadow-[0_0_10px_rgba(59,130,246,0.5)] scale-110' : 'border-slate-300') }}">
                        
                        @if($isDone)
                            <div class="w-2.5 h-2.5 rounded-full bg-emerald-500"></div>
                        @elseif($isActive)
                            <div class="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse"></div>
                        @else
                            <div class="w-1.5 h-1.5 rounded-full bg-slate-300"></div>
                        @endif
                    </div>

                    {{-- KONTEN TEKS --}}
                    {{-- PERBAIKAN: Memisahkan atribut class (statis) dan :class (dinamis) --}}
                    <div class="flex-1 -mt-1 p-3 rounded-lg border transition-all duration-300"
                         :class="activeView == {{ $num }} ? 'bg-white border-blue-500 shadow-md translate-x-1' : 
                                '{{ $isActive ? 'bg-white border-blue-200 shadow-sm' : 'bg-transparent border-transparent' }}'">
                        
                        <div class="flex justify-between items-center mb-1">
                            <span class="text-sm font-bold transition-colors"
                                  :class="activeView == {{ $num }} ? 'text-blue-700' : 
                                         '{{ $isDone ? 'text-emerald-700' : ($isActive ? 'text-blue-700' : 'text-slate-500') }}'">
                                {{ $item['label'] }}
                            </span>
                            
                            {{-- Badge Status --}}
                            @if($isDone)
                                <i class="fas fa-check-circle text-emerald-500 text-sm"></i>
                            @elseif($isActive)
                                <span class="text-[9px] font-mono bg-blue-100 text-blue-600 px-1.5 py-0.5 rounded">RUNNING</span>
                            @endif
                        </div>

                        {{-- ID Step --}}
                        <div class="text-[10px] font-mono text-slate-400 flex items-center gap-2">
                            <span>{{ $item['id'] }}</span>
                            @if($isActive) 
                                <span class="w-1 h-1 rounded-full bg-blue-400 animate-ping"></span>
                            @endif
                        </div>
                    </div>

                </div>
            @endforeach
        </div>
    </div>

    
    {{-- ================================================= --}}
    {{-- DESKTOP VIEW (ORBITAL INTERAKTIF)                 --}}
    {{-- ================================================= --}}
    <div class="hidden md:flex items-center justify-center min-h-[420px] relative z-10">
        
        {{-- ORBIT TRACKS --}}
        <div class="absolute w-[340px] h-[340px] rounded-full border border-blue-100/30 transition-all duration-1000 delay-100" :class="mounted ? 'scale-100 opacity-100' : 'scale-50 opacity-0'"></div>
        <div class="absolute w-[260px] h-[260px] rounded-full border border-dashed border-blue-200/40 animate-spin-slow transition-all duration-1000 delay-200" style="animation-duration: 120s;" :class="mounted ? 'scale-100 opacity-100' : 'scale-50 opacity-0'"></div>
        <div class="absolute w-[180px] h-[180px] rounded-full border border-blue-50/50 transition-all duration-1000 delay-300" :class="mounted ? 'scale-100 opacity-100' : 'scale-50 opacity-0'"></div>

        {{-- CENTER PROGRESS --}}
        <div class="absolute z-20 w-36 h-36 rounded-full flex items-center justify-center bg-white/90 backdrop-blur-md shadow-[0_0_30px_rgba(59,130,246,0.15)] border border-blue-100 transition-all duration-700 delay-300" :class="mounted ? 'scale-100 opacity-100' : 'scale-0 opacity-0'">
            
            {{-- SVG PROGRESS --}}
            {{-- Kita pakai viewBox 100 100 agar perhitungan circumference tetap 283 (2 * pi * 45) --}}
            <svg class="absolute inset-0 w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                {{-- Lingkaran Background (Abu-abu) --}}
                <circle cx="50" cy="50" r="45" fill="none" stroke="#f1f5f9" stroke-width="5" />
                
                {{-- Lingkaran Progress (Biru) --}}
                <circle 
                    cx="50" cy="50" r="45" 
                    fill="none" 
                    stroke="#3b82f6" 
                    stroke-width="5" 
                    stroke-linecap="round" 
                    stroke-dasharray="283" 
                    {{-- RUMUS FIX: Kita pastikan hasilnya 0 saat 100% --}}
                    :stroke-dashoffset="283 - (currentPercent / 100 * 283)" 
                    class="transition-all duration-300 ease-out drop-shadow-md" 
                />
            </svg>

            <div class="text-center relative z-10 flex flex-col items-center">
                <span class="text-[9px] font-mono text-slate-400 uppercase tracking-widest mb-0.5">Total</span>
                <div class="text-3xl font-black text-slate-800 tracking-tighter">
                    <span x-text="currentPercent"></span><span class="text-lg text-blue-500 font-bold">%</span>
                </div>
                <div class="mt-2 flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-50 border border-blue-100">
                    <div class="w-1.5 h-1.5 rounded-full {{ $percentage >= 100 ? 'bg-emerald-500' : 'bg-blue-500 animate-pulse' }}"></div>
                    <span class="text-[9px] font-bold uppercase text-slate-600 tracking-wide">{{ $mainStatus }}</span>
                </div>
            </div>
        </div>

        {{-- ICONS / NODES (CLICKABLE) --}}
        <div class="absolute inset-0 w-full h-full pointer-events-none">
            @foreach($steps as $num => $item)
                @php
                    $radius = 130; 
                    $angleDeg = (($num - 1) * 60) - 90;
                    $angleRad = deg2rad($angleDeg);
                    $isDone = $item['status'] == 'completed';
                    $isActive = $item['status'] == 'active';

                    // Posisi Label
                    $posClass = ''; $alignClass = '';
                    if ($angleDeg == -90) { $posClass = 'bottom-[3.5rem]'; $alignClass = 'items-center'; }
                    elseif ($angleDeg == 90) { $posClass = 'top-[3.5rem]'; $alignClass = 'items-center'; }
                    elseif ($angleDeg > -90 && $angleDeg < 90) { $posClass = 'left-[3.5rem]'; $alignClass = 'items-start pl-2'; }
                    else { $posClass = 'right-[3.5rem]'; $alignClass = 'items-end pr-2'; }
                @endphp

                <div id="nav-desktop-step-{{ $num }}" @click="activeView = {{ $num }}; window.scrollTo({ top: 0, behavior: 'smooth' })"
                     class="absolute transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group pointer-events-auto cursor-pointer"
                     style="left: calc(50% + {{ $radius * cos($angleRad) }}px); top: calc(50% + {{ $radius * sin($angleRad) }}px);">
                    
                    {{-- Connector Line --}}
                    <div class="absolute top-1/2 left-1/2 h-[1px] bg-blue-300/50 origin-left -z-10 transition-all duration-1000 ease-out"
                         x-show="mounted"
                         x-transition:enter="transition duration-1000"
                         x-transition:enter-start="w-0 opacity-0"
                         x-transition:enter-end="w-full opacity-100"
                         style="width: {{ $isActive ? '70px' : '0px' }}; transform: rotate({{ $angleDeg + 180 }}deg); transition-delay: {{ 500 + ($num * 100) }}ms">
                    </div>

                    {{-- ICON CIRCLE --}}
                    <div x-show="mounted"
                         x-transition:enter="transition ease-out duration-500"
                         x-transition:enter-start="opacity-0 scale-0"
                         x-transition:enter-end="opacity-100 scale-100"
                         style="transition-delay: {{ 600 + ($num * 100) }}ms"
                         class="relative z-30 w-12 h-12 rounded-full flex items-center justify-center border-4 transition-all duration-300 group-hover:scale-110 group-active:scale-95"
                         :class="activeView == {{ $num }} ? 'bg-blue-600 border-blue-400 shadow-[0_0_25px_rgba(37,99,235,0.6)] scale-110' : 
                                 '{{ $isActive ? 'bg-white border-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.3)]' : 
                                   ($isDone ? 'bg-emerald-500 border-emerald-200 shadow-md' : 'bg-white/80 border-blue-100 backdrop-blur-sm group-hover:border-blue-300') }}'">
                        
                        <i class="fas fa-{{ $item['icon'] }} text-base transition-colors"
                           :class="activeView == {{ $num }} ? 'text-white' : 
                                   '{{ $isDone ? 'text-white' : ($isActive ? 'text-blue-600' : 'text-slate-400 group-hover:text-blue-500') }}'"></i>

                        @if($isActive)
                            <div class="absolute -inset-1 rounded-full border border-blue-300 animate-ping opacity-50" x-show="activeView != {{ $num }}"></div>
                        @endif
                    </div>

                    {{-- LABEL INFO --}}
                    <div x-show="mounted"
                         x-transition:enter="transition ease-out duration-500"
                         x-transition:enter-start="opacity-0 translate-y-2"
                         x-transition:enter-end="opacity-100 translate-y-0"
                         style="transition-delay: {{ 700 + ($num * 100) }}ms"
                         class="absolute w-36 flex flex-col {{ $alignClass }} justify-center pointer-events-none {{ $posClass }}">
                        
                        <div class="text-[8px] font-mono text-slate-400 mb-0.5 tracking-wider">{{ $item['id'] }}</div>

                        <div class="backdrop-blur-md px-2.5 py-1 rounded-lg border shadow-sm transition-all duration-300"
                             :class="activeView == {{ $num }} ? 'bg-blue-600 border-blue-500 shadow-blue-200 -translate-y-1' : 
                                     '{{ $isActive ? 'bg-white/90 border-blue-300 shadow-blue-100' : 
                                       ($isDone ? 'bg-emerald-50/50 border-emerald-200' : 'bg-white/70 border-blue-100/50 opacity-70') }}'">
                            
                            <h4 class="font-bold text-[10px] uppercase tracking-wide whitespace-nowrap transition-colors"
                                :class="activeView == {{ $num }} ? 'text-white' : 
                                        '{{ $isActive ? 'text-blue-700' : ($isDone ? 'text-emerald-700' : 'text-slate-600') }}'">
                                {{ $item['label'] }}
                            </h4>
                        </div>

                        <div class="mt-1 flex items-center gap-1.5" x-show="activeView == {{ $num }}">
                            <div class="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse"></div>
                            <span class="text-[9px] font-bold uppercase text-blue-600">Viewing</span>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>

{{-- CARD STATUS KELULUSAN (THEME: UBP PRIDE) --}}
    <div class="mt-8 relative overflow-hidden rounded-2xl border transition-all duration-500 hover:shadow-2xl hover:scale-[1.01]
                {{-- LOGIKA WARNA BACKGROUND & BORDER --}}
                {{ $rankTheme == 'emerald' 
                    ? 'bg-gradient-to-br from-blue-950 via-blue-900 to-blue-800 border-yellow-400 shadow-blue-900/50' 
                    : ($rankTheme == 'red' ? 'bg-red-900 border-red-700' : 'bg-slate-900 border-slate-800') }} 
                p-6 shadow-xl">
        
        {{-- Background Pattern --}}
        <div class="absolute inset-0 opacity-10" style="background-image: url('https://www.transparenttextures.com/patterns/cubes.png');"></div>
        
        {{-- Dekorasi Cahaya (Glow Effect) --}}
        @if($rankTheme == 'emerald')
            <div class="absolute top-0 right-0 -mt-10 -mr-10 w-40 h-40 bg-yellow-400 rounded-full blur-[80px] opacity-20 animate-pulse"></div>
            <div class="absolute bottom-0 left-0 -mb-10 -ml-10 w-40 h-40 bg-red-600 rounded-full blur-[80px] opacity-20"></div>
        @endif
        
        <div class="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
            
            {{-- Kiri: Icon & Title --}}
            <div class="flex items-center gap-5 text-center md:text-left w-full md:w-auto justify-center md:justify-start">
                {{-- KOTAK IKON: Merah UBP saat Lulus --}}
                <div class="w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg border border-white/10
                            {{ $rankTheme == 'emerald' ? 'bg-red-700 text-white shadow-red-900/50' : 'bg-slate-800 text-slate-500' }}">
                    <i class="fas fa-{{ $rankIcon }} text-3xl"></i>
                </div>
                
                <div>
                    {{-- LABEL KECIL: Kuning Emas saat Lulus --}}
                    <p class="text-xs font-mono font-bold uppercase tracking-[0.2em] mb-1
                              {{ $rankTheme == 'emerald' ? 'text-yellow-400 drop-shadow-sm' : 'text-slate-500' }}">
                        Status Seleksi
                    </p>
                    
                    {{-- JUDUL UTAMA: Putih Tegas --}}
                    <h2 class="text-3xl font-black italic uppercase tracking-tighter text-white">
                        {{ $rankTitle }}
                    </h2>
                </div>
            </div>

            {{-- Kanan: Detail Content --}}
            <div class="w-full md:w-auto bg-black/20 backdrop-blur-sm rounded-xl p-4 border border-white/10 min-w-[200px]">
                @if($isContentHidden)
                    {{-- Tampilan Terkunci (Formal) --}}
                    <div class="flex items-center justify-center gap-3 text-slate-300">
                        <i class="fas fa-lock text-xl animate-pulse text-yellow-500"></i>
                        <div class="text-left">
                            <p class="text-[10px] uppercase tracking-wider text-slate-400">Informasi Terkunci</p>
                            <p class="text-sm font-bold text-white">Selesaikan Administrasi</p>
                        </div>
                    </div>
                @else
                    {{-- Tampilan Normal (Lulus/Placeholder) --}}
                    <div class="text-center md:text-right">
                        <p class="text-[10px] uppercase tracking-wider mb-1 
                                  {{ $rankTheme == 'emerald' ? 'text-yellow-400' : 'text-slate-400' }}">
                            Program Studi
                        </p>
                        <p class="text-xl font-bold text-white tracking-wide">
                            {{ $rankSubtitle }}
                        </p>
                    </div>
                @endif
            </div>

        </div>
    </div>
    
    @if($rankTheme != 'emerald' && $rankTheme != 'red') 
        <div class="mt-4 relative overflow-hidden rounded-xl border border-amber-400/50 bg-gradient-to-r from-amber-50/90 via-white/90 to-white/80 backdrop-blur-md p-1 group shadow-sm">
            
            {{-- Dekorasi Glow Halus --}}
            <div class="absolute -top-10 -right-10 w-32 h-32 bg-amber-400/20 rounded-full blur-3xl group-hover:bg-amber-400/30 transition-all duration-700"></div>
    
            <div class="flex items-start gap-4 p-4 relative z-10">
                {{-- Ikon --}}
                <div class="flex-shrink-0 mt-1">
                    <div class="w-10 h-10 rounded-lg bg-amber-100 border border-amber-200 flex items-center justify-center shadow-sm">
                        <i class="fas fa-info-circle text-amber-600 text-xl"></i>
                    </div>
                </div>
    
                {{-- Konten Teks --}}
                <div class="flex-1">
                    <div class="flex items-center gap-2 mb-1">
                        <h3 class="text-gray-900 font-bold text-sm tracking-wide">
                            Informasi Kuota & Akun
                        </h3>
                        <span class="px-2 py-0.5 rounded text-[9px] bg-amber-200 text-amber-800 border border-amber-300 font-bold uppercase tracking-wider">
                            Limited Slot
                        </span>
                    </div>
                    
                    {{-- UPDATE DISINI: registrasi ulang -> pembayaran UKT --}}
                    <p class="text-gray-700 text-xs leading-relaxed font-medium">
                        Sistem akan melakukan <span class="text-black font-extrabold border-b border-dashed border-gray-400">reset data otomatis</span> pada pergantian gelombang. 
                        Demi keamanan akun, silakan <span class="text-amber-700 font-bold">selesaikan ujian</span> dan 
                        <span class="text-emerald-700 font-bold">pembayaran UKT</span> untuk mengunci kuota kursi Anda.
                    </p>
                </div>
            </div>
    
            {{-- Bottom Line --}}
            <div class="absolute bottom-0 left-0 w-full h-[3px] bg-gray-200">
                <div class="h-full bg-gradient-to-r from-amber-500 to-transparent w-1/3 opacity-80"></div>
            </div>
        </div>
    @endif