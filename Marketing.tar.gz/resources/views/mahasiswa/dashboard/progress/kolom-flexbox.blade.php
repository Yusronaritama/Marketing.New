{{-- Container Utama: w-full dan hapus gap (gap-0) agar benar-benar mentok --}}
<div class="flex flex-col md:flex-row w-full gap-0 flex-grow">
    
    {{-- BAGIAN KIRI (50%) --}}
    {{-- md:w-1/2 (Setengah layar penuh) --}}
    {{-- md:pr-6 (Padding kanan internal agar tulisan tidak menabrak garis batas) --}}
    <div class="w-full md:w-1/2 md:pr-6">
        <h3 class="text-lg font-bold text-gray-900 drop-shadow-sm mb-3">
            Progres Pendaftaran Anda
        </h3>
        
        @include('mahasiswa.dashboard.progress.kiri.index')
    </div>

    {{-- BAGIAN KANAN (50%) --}}
    {{-- md:w-1/2 (Setengah layar penuh) --}}
    {{-- md:pl-6 (Padding kiri internal setelah garis batas) --}}
    <div class="w-full md:w-1/2 md:border-l md:border-white/20 md:pl-6 flex flex-col">    
        @include('mahasiswa.dashboard.progress.kanan.index')
    </div>

</div>