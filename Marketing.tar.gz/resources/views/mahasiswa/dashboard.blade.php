@extends('layouts.mahasiswa.app')

@section('title', 'Dashboard Mahasiswa')

{{-- ======================================================================= --}}
{{-- 1. FLOATING HELP WIDGET (DRAGGABLE)                                     --}}
{{-- ======================================================================= --}}
<div x-data="{ 
        open: false,
        isDragging: false,
        isClicking: false,
        offset: { x: 0, y: 0 },
        start: { x: 0, y: 0 },
        
        dragStart(e) {
            this.isDragging = true;
            this.isClicking = true;
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;
            this.start.x = clientX - this.offset.x;
            this.start.y = clientY - this.offset.y;
        },

        dragging(e) {
            if (!this.isDragging) return;
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;
            this.offset.x = clientX - this.start.x;
            this.offset.y = clientY - this.start.y;

            if (Math.abs(this.offset.x) > 5 || Math.abs(this.offset.y) > 5) {
                this.isClicking = false;
            }
        },

        dragEnd() {
            this.isDragging = false;
        },

        toggle() {
            if (this.isClicking) {
                this.open = !this.open;
            }
        }
     }" 
     x-on:mousemove.window="dragging($event)"
     x-on:mouseup.window="dragEnd()"
     x-on:touchmove.window="dragging($event)"
     x-on:touchend.window="dragEnd()"
     class="fixed bottom-6 right-6 z-[990] flex flex-col items-end"
     :style="`transform: translate(${offset.x}px, ${offset.y}px); touch-action: none;`">

    {{-- DROPDOWN MENU --}}
    <div x-show="open" 
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0 translate-y-4 scale-95"
         x-transition:enter-end="opacity-100 translate-y-0 scale-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100 translate-y-0 scale-100"
         x-transition:leave-end="opacity-0 translate-y-4 scale-95"
         class="mb-4 w-56 bg-white rounded-2xl shadow-2xl border border-slate-100 p-2 pointer-events-auto origin-bottom-right relative overflow-hidden select-none">
        
        <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-green-400 to-emerald-600"></div>
        <div class="p-2 border-b border-slate-50 mb-2">
            <h4 class="text-xs font-black text-slate-700 uppercase tracking-wide">Pusat Bantuan</h4>
            <p class="text-[10px] text-slate-400 font-mono">Pilih admin untuk chat:</p>
        </div>
        <div class="space-y-2">
            <a href="https://wa.me/6281234567890" target="_blank" class="group flex items-center gap-3 p-2.5 rounded-xl hover:bg-green-50 transition-colors border border-transparent hover:border-green-100">
                <div class="w-8 h-8 rounded-full bg-green-100 text-green-600 flex items-center justify-center shrink-0 shadow-sm"><i class="fab fa-whatsapp"></i></div>
                <div>
                    <span class="block text-xs font-bold text-slate-700 group-hover:text-green-700">Admin 1</span>
                    <span class="block text-[9px] text-slate-400 group-hover:text-green-600 flex items-center gap-1"><span class="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span> Online</span>
                </div>
            </a>
            <a href="https://wa.me/6289876543210" target="_blank" class="group flex items-center gap-3 p-2.5 rounded-xl hover:bg-green-50 transition-colors border border-transparent hover:border-green-100">
                <div class="w-8 h-8 rounded-full bg-green-100 text-green-600 flex items-center justify-center shrink-0 shadow-sm"><i class="fab fa-whatsapp"></i></div>
                <div>
                    <span class="block text-xs font-bold text-slate-700 group-hover:text-green-700">Admin 2</span>
                    <span class="block text-[9px] text-slate-400 group-hover:text-green-600 flex items-center gap-1"><span class="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span> Online</span>
                </div>
            </a>
        </div>
    </div>

    {{-- TRIGGER BUTTON --}}
    <button x-on:mousedown="dragStart($event)"
            x-on:touchstart.passive="dragStart($event)"
            x-on:click="toggle()"
            class="pointer-events-auto relative group flex items-center justify-center w-14 h-14 rounded-full shadow-[0_4px_20px_rgba(16,185,129,0.4)] hover:shadow-[0_4px_25px_rgba(16,185,129,0.6)] transition-shadow duration-300 transform hover:scale-105 active:scale-95 bg-gradient-to-br from-emerald-500 to-green-600 text-white cursor-move select-none">
        <span class="absolute inset-0 rounded-full border-2 border-white opacity-20 animate-ping pointer-events-none"></span>
        <div class="relative w-6 h-6 pointer-events-none">
            <i class="fas fa-headset text-2xl absolute inset-0 transition-all duration-300 transform"
               :class="open ? 'opacity-0 rotate-90 scale-50' : 'opacity-100 rotate-0 scale-100'"></i>
            <i class="fas fa-times text-2xl absolute inset-0 transition-all duration-300 transform"
               :class="open ? 'opacity-100 rotate-0 scale-100' : 'opacity-0 -rotate-90 scale-50'"></i>
        </div>
        <span x-show="!open && !isDragging" 
              x-transition.opacity
              class="absolute right-16 bg-white text-slate-700 px-3 py-1.5 rounded-lg text-xs font-bold shadow-md border border-slate-100 whitespace-nowrap hidden md:block pointer-events-none">
            Butuh Bantuan?
            <span class="absolute top-1/2 -right-1.5 -mt-1 w-2 h-2 bg-white border-t border-r border-slate-100 transform rotate-45"></span>
        </span>
    </button>
</div>

                {{-- ======================================================================= --}}
                {{-- [BARU] BUTTON GRUP WA (DRAGGABLE / BISA DIGESER)                        --}}
                {{-- ======================================================================= --}}
                @php
                    $linkWaAktif = '';
                    if(isset($listGroupWA) && count($listGroupWA) > 0) {
                        $grup = $listGroupWA->where('is_active', true)->first() ?? $listGroupWA->last();
                        if($grup && !empty($grup->link_group) && $grup->link_group !== '#') {
                            $linkWaAktif = $grup->link_group;
                        }
                    }
                @endphp
            
                @if($linkWaAktif !== '')
                    <div x-data="{ 
                            isDragging: false,
                            hasDragged: false,
                            offset: { x: 0, y: 0 },
                            start: { x: 0, y: 0 },
                            
                            dragStart(e) {
                                this.isDragging = true;
                                this.hasDragged = false;
                                const clientX = e.touches ? e.touches[0].clientX : e.clientX;
                                const clientY = e.touches ? e.touches[0].clientY : e.clientY;
                                this.start.x = clientX - this.offset.x;
                                this.start.y = clientY - this.offset.y;
                            },
            
                            dragging(e) {
                                if (!this.isDragging) return;
                                const clientX = e.touches ? e.touches[0].clientX : e.clientX;
                                const clientY = e.touches ? e.touches[0].clientY : e.clientY;
                                
                                const newOffsetX = clientX - this.start.x;
                                const newOffsetY = clientY - this.start.y;
                                
                                // Kalau kegeser lebih dari 5 pixel, berarti dia niatnya nge-drag, bukan nge-klik
                                if (Math.abs(newOffsetX - this.offset.x) > 5 || Math.abs(newOffsetY - this.offset.y) > 5) {
                                    this.hasDragged = true;
                                }
                                
                                this.offset.x = newOffsetX;
                                this.offset.y = newOffsetY;
                            },
            
                            dragEnd() {
                                this.isDragging = false;
                            },
                            
                            goToLink(link) {
                                // Kalau murni di-klik (tidak digeser), baru buka linknya
                                if (!this.hasDragged) {
                                    window.open(link, '_blank');
                                }
                            }
                         }" 
                         x-on:mousemove.window="dragging($event)"
                         x-on:mouseup.window="dragEnd()"
                         x-on:touchmove.window="dragging($event)"
                         x-on:touchend.window="dragEnd()"
                         class="fixed bottom-6 left-6 z-[990] flex flex-col items-start"
                         :style="`transform: translate(${offset.x}px, ${offset.y}px); touch-action: none;`">
            
                        <button x-on:mousedown="dragStart($event)"
                                x-on:touchstart.passive="dragStart($event)"
                                x-on:click="goToLink('{{ $linkWaAktif }}')"
                                title="Join Grup WhatsApp PMB" 
                                class="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white px-4 py-2.5 rounded-full shadow-[0_4px_15px_rgba(16,185,129,0.4)] border-2 border-white flex items-center gap-2 transition-transform active:scale-95 group cursor-move select-none">
                            
                            {{-- pointer-events-none biar kliknya nggak nyangkut di icon --}}
                            <div class="relative flex items-center justify-center pointer-events-none">
                                <span class="absolute inline-flex h-full w-full rounded-full bg-white opacity-20 group-hover:animate-ping"></span>
                                <i class="fab fa-whatsapp text-xl"></i>
                            </div>
                            <span class="text-xs font-black uppercase tracking-wider pointer-events-none">Grup WA Maba</span>
                        </button>
                    </div>
                @endif

{{-- ======================================================================= --}}
{{-- 2. OPENING SCREEN (LOADING)                                             --}}
{{-- ======================================================================= --}}
@push('opening_screen')
    @if(session('just_logged_in')) 
        <div x-data="{ 
                show: true,
                completed: false,
                progress: 0,
                init() {
                    document.body.style.overflow = 'hidden';
                    let timer = setInterval(() => {
                        this.progress += Math.random() * 2.5; 
                        
                        if (this.progress >= 100) {
                            this.progress = 100;
                            clearInterval(timer);
                            this.completed = true;
                            setTimeout(() => {
                                this.show = false;
                                document.body.style.overflow = 'auto';
                            }, 1000);
                        }
                    }, 50); 
                }
            }"
            x-show="show"
            x-transition:leave="transition-all ease-in-out duration-1000"
            x-transition:leave-start="opacity-100 scale-100 blur-0"
            x-transition:leave-end="opacity-0 scale-105 blur-sm"
            class="fixed inset-0 z-[9999] flex items-center justify-center overflow-hidden font-sans select-none bg-[#050a14]">

            {{-- Background Effects --}}
            <div class="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-900/30 via-[#050a14] to-[#050a14] pointer-events-none"></div>
            <div class="absolute inset-0 bg-[linear-gradient(to_right,#3b82f61a_1px,transparent_1px),linear-gradient(to_bottom,#3b82f61a_1px,transparent_1px)] bg-[size:40px_40px] opacity-20 pointer-events-none"></div>
            
            <div class="relative z-10 flex flex-col items-center justify-center text-center transition-all duration-1000"
                 style="min-width: 100vw;"
                 :class="completed ? 'scale-95 opacity-0' : 'scale-100 opacity-100'">
                
                {{-- HEADER: LOGO & TYPOGRAPHY --}}
                <div class="flex flex-col items-center justify-center w-full mb-8">
                    <div class="relative animate-float-slow mb-6">
                        <div class="absolute inset-0 bg-blue-500/40 blur-[60px] rounded-full animate-pulse-slow"></div>
                        <img 
                            src="{{ asset('images/logo_ubp.png') }}" 
                            onerror="this.onerror=null; this.src='https://ubpkarawang.ac.id/wp-content/uploads/2021/08/Logo-UBP-Karawang.png';" 
                            alt="Logo" 
                            class="h-28 w-auto relative z-10 drop-shadow-[0_10px_20px_rgba(59,130,246,0.5)] animate-intro-fade-up"
                            style="animation-delay: 0.1s"
                        >
                    </div>
                    <div class="space-y-2">
                        <p class="text-blue-300/80 text-xs md:text-sm font-medium tracking-[0.5em] uppercase animate-intro-fade-up" style="animation-delay: 0.3s">Selamat Datang di</p>
                        <h1 class="text-3xl md:text-5xl font-black tracking-tight text-white uppercase animate-intro-fade-up" style="animation-delay: 0.5s; text-shadow: 0 0 40px rgba(59,130,246,0.6);">
                            UBP <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-white">KARAWANG</span>
                        </h1>
                    </div>
                </div>
 
                {{-- CIRCULAR LOADER SECTION --}}
                <div class="flex items-center justify-center w-full min-h-[160px] animate-intro-fade-in" style="animation-delay: 0.8s">
                    <div class="loader-wrapper">
                        <div class="circular-loader">
                            <div class="orbit-container">
                                <div class="moving-ball"></div>
                            </div>
                            <span class="loader-inner">
                                <i class="gradient-border"></i>
                                <div class="percentage-box">
                                    <span class="loading-text">LOADING</span>
                                    <span class="num" x-text="Math.floor(progress) + '%'"></span>
                                </div>
                            </span>
                        </div>
                    </div>
                </div>

                <p class="text-slate-500 text-[10px] uppercase tracking-widest mt-8 animate-intro-fade-in" style="animation-delay: 1.2s">Sistem PMB Online &bull; 2025</p>
            </div>
 
            <style>
                /* Layout & Alignment Fix */
                .loader-wrapper {
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    /* Mengatasi sisa ruang akibat scaling */
                    transform: scale(0.55);
                    width: 250px; 
                    height: 250px;
                }

                .circular-loader {
                    position: relative;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }

                .loader-inner {
                    position: relative;
                    width: 250px;
                    height: 250px;
                    background-color: #050a14;
                    border: 6px solid #0a1224;
                    box-shadow: -8px -8px 15px rgba(255, 255, 255, 0.03), 8px 8px 25px rgba(0, 0, 0, 0.6);
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    overflow: hidden;
                }

                /* Middle UI */
                .percentage-box {
                    display: flex;
                    flex-direction: column;
                    align-items: center;
                    justify-content: center;
                    z-index: 10;
                    position: absolute;
                    inset: 35px;
                    background-color: #050a14;
                    box-shadow: 
                        -8px -8px 25px rgba(255, 255, 255, 0.03), 
                        8px 8px 25px rgba(0, 0, 0, 0.6), 
                        inset 3px 3px 10px rgba(0, 0, 0, 0.7), 
                        inset -1px -1px 15px rgba(255, 255, 255, 0.03);
                    border: 2px solid #0a1224;
                    border-radius: 50%;
                }

                .loading-text {
                    font-weight: 900;
                    color: #1e40af;
                    letter-spacing: 4px;
                    font-size: 18px;
                    margin-bottom: 5px;
                }

                .num {
                    color: #3b82f6;
                    font-family: 'Monaco', monospace;
                    font-weight: bold;
                    font-size: 24px;
                }

                .gradient-border {
                    position: absolute;
                    inset: 0;
                    background: linear-gradient(#1e3a8a, #3b82f6, #60a5fa);
                    border-radius: 50%;
                    filter: blur(5px);
                    animation: rotateCircle 1.2s linear infinite;
                }

                @keyframes rotateCircle {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }

                .orbit-container {
                    position: absolute;
                    /* Ukuran diperbesar agar jarak orbit makin jauh dari lingkaran utama (250px) */
                    width: 340px; 
                    height: 340px;
                    border-radius: 50%;
                    animation: rotateOrbit 5s linear infinite;
                    z-index: 20;
                }

                @keyframes rotateOrbit {
                    0% { transform: rotate(360deg); }
                    100% { transform: rotate(0deg); }
                }

                .moving-ball {
                    position: absolute;
                    top: 50%;
                    left: -25px;
                    transform: translateY(-50%);
                    width: 55px;
                    height: 55px;
                    background: linear-gradient(135deg, #3b82f6, #1e40af);
                    border: 5px solid #0a1224;
                    border-radius: 50%;
                    box-shadow: 0 0 25px rgba(59, 130, 246, 0.5);
                }

                @keyframes introFadeUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
                .animate-intro-fade-up { animation: introFadeUp 1s cubic-bezier(0.2, 0.8, 0.2, 1) forwards; opacity: 0; }
                @keyframes introFadeIn { from { opacity: 0; } to { opacity: 1; } }
                .animate-intro-fade-in { animation: introFadeIn 1s ease-out forwards; opacity: 0; }
                @keyframes floatSlow { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
                .animate-float-slow { animation: floatSlow 6s ease-in-out infinite; }
                @keyframes pulseSlow { 0%, 100% { opacity: 0.6; scale: 1; } 50% { opacity: 1; scale: 1.1; } }
                .animate-pulse-slow { animation: pulseSlow 4s ease-in-out infinite; }
            </style>
        </div>
    @endif
@endpush



{{-- ======================================================================= --}}
{{-- 3. MAIN CONTENT (DENGAN LOGIKA AUTO-REDIRECT LULUS)                     --}}
{{-- ======================================================================= --}}
@section('content')

    {{-- [SUPER AMAN] WADAH DATA JSON RAHASIA BIAR KUTIP NGGAK TABRAKAN --}}
    <script id="waGroupData" type="application/json">
        {!! json_encode($listGroupWA ?? []) !!}
    </script>

    <div class="relative mt-4">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
            {{-- BARIS 1: PROGRESS UTAMA (Isinya Wave Monitor, Step 3 Ujian, dll) --}}
            <div class="lg:col-span-12 order-1">
                @include('mahasiswa.dashboard.progress-layouts')
            </div>

            {{-- ========================================================= --}}
            {{-- [BARU] BARIS 1.5: BANNER GRUP WA PERMANEN                 --}}
            {{-- ========================================================= --}}
            <div class="lg:col-span-12 order-2" 
                 x-data="{ 
                     waLink: '',
                     groupList: [], 
                     init() {
                         this.$nextTick(() => {
                             // Tarik data aman dari script rahasia di atas
                             let rawData = document.getElementById('waGroupData').textContent;
                             this.groupList = JSON.parse(rawData || '[]');

                             const now = new Date();
                             const month = now.getMonth(); 
                             let wave = (month === 11 || month === 0) ? 1 : (month === 10 ? -1 : month + 1);
                             
                             let group = Array.isArray(this.groupList) ? this.groupList.find(g => g.gelombang == wave) : null;
                             
                             if (group && group.link_group) {
                                 this.waLink = group.link_group;
                             }
                         });
                     }
                 }">
                
                <div x-show="waLink !== ''" 
                     x-transition.opacity.duration.500ms
                     style="display: none;"
                     class="bg-gradient-to-r from-emerald-500 to-green-600 rounded-xl p-5 shadow-md flex flex-col md:flex-row items-center justify-between gap-4 border border-emerald-400 relative overflow-hidden group">
                    
                    {{-- Hiasan Background WA --}}
                    <div class="absolute right-0 top-0 opacity-10 transform translate-x-4 -translate-y-4 pointer-events-none transition-transform duration-500 group-hover:scale-110">
                        <i class="fab fa-whatsapp text-8xl"></i>
                    </div>
                    
                    <div class="flex items-center gap-4 text-white relative z-10 w-full md:w-auto">
                        <div class="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center shrink-0 border border-white/30 backdrop-blur-sm">
                            <i class="fab fa-whatsapp text-3xl animate-bounce"></i>
                        </div>
                        <div>
                            <h4 class="font-black text-lg md:text-xl leading-none mb-1 uppercase tracking-wide">Grup WhatsApp PMB</h4>
                            <p class="text-xs md:text-sm text-emerald-50 font-medium">Gabung sekarang agar tidak ketinggalan informasi penting!</p>
                        </div>
                    </div>
                    
                    <a :href="waLink" target="_blank" class="w-full md:w-auto shrink-0 bg-white text-emerald-700 hover:bg-emerald-50 px-8 py-3 rounded-xl font-black text-sm shadow-lg transition-all transform hover:scale-105 hover:-translate-y-1 text-center uppercase tracking-wider relative z-10 flex items-center justify-center gap-2">
                        <i class="fas fa-sign-in-alt"></i> Gabung Grup
                    </a>
                </div>
            </div>
            {{-- ========================================================= --}}

            {{-- BARIS 2: KONTEN TAMBAHAN --}}
            <div class="lg:col-span-6 order-3">
                @include('mahasiswa.dashboard.partials.carousel_kiri')
            </div>
            <div class="lg:col-span-6 order-4">
                @include('mahasiswa.dashboard.partials.info-carousel')
            </div>

        </div>
    </div>

    {{-- =================================================================== --}}
    {{-- 4. GLOBAL POPUP WHATSAPP (ONCE PER WAVE - WITH HINT TRIGGER)        --}}
    {{-- =================================================================== --}}
    <div x-data="{ 
            showWAModal: false,
            waLink: '',
            groupList: [], 

            init() {
                // Tarik data aman dari script rahasia di atas
                let rawData = document.getElementById('waGroupData').textContent;
                this.groupList = JSON.parse(rawData || '[]');

                const now = new Date();
                const month = now.getMonth(); 
                let wave = (month === 11 || month === 0) ? 1 : (month === 10 ? -1 : month + 1);

                let group = Array.isArray(this.groupList) ? this.groupList.find(g => g.gelombang == wave) : null;

                if (group && group.link_group) {
                    this.waLink = group.link_group;

                    const storageKey = 'wa_popup_count_wave_' + wave;
                    let currentCount = parseInt(localStorage.getItem(storageKey) || '0');

                    if (currentCount < 2) {
                        setTimeout(() => { 
                            this.showWAModal = true;
                            localStorage.setItem(storageKey, currentCount + 1);
                        }, 3500);
                    }
                }
            },

            closeModal() {
                this.showWAModal = false;
            },

            joinGroup() {
                if (this.waLink) {
                    window.open(this.waLink, '_blank');
                    this.showWAModal = false; 
                    this.markAsDoneForever();
                }
            },

            markAsDoneForever() {
                const now = new Date();
                const month = now.getMonth(); 
                const wave = (month === 11 || month === 0) ? 1 : (month === 10 ? -1 : month + 1);
                localStorage.setItem('wa_popup_count_wave_' + wave, '99');
            }
        }"
        x-init="init()"
        class="relative z-[9995]">

        {{-- Overlay Gelap --}}
        <div x-show="showWAModal" 
             x-transition.opacity
             class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm"
             style="display: none;"></div>

        {{-- Modal Box --}}
        <div id="wa-modal-overlay" x-show="showWAModal"
             style="display: none;"
             x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="opacity-0 scale-90 translate-y-4"
             x-transition:enter-end="opacity-100 scale-100 translate-y-0"
             x-transition:leave="transition ease-in duration-200"
             x-transition:leave-start="opacity-100 scale-100 translate-y-0"
             x-transition:leave-end="opacity-0 scale-90 translate-y-4"
             class="fixed inset-0 flex items-center justify-center p-4">
            
            <div class="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden relative border-4 border-white">
                <div class="bg-emerald-500 h-28 flex flex-col items-center justify-center relative overflow-hidden">
                    <div class="absolute inset-0 bg-black/10 opacity-20" style="background-image: radial-gradient(#fff 1px, transparent 1px); background-size: 10px 10px;"></div>
                    <i class="fab fa-whatsapp text-6xl text-white drop-shadow-md animate-bounce mb-2"></i>
                    <p class="text-white font-bold relative z-10">Grup WhatsApp Seleksi</p>
                    <button @click="closeModal()" class="absolute top-3 right-3 text-white/80 hover:text-white bg-black/10 hover:bg-black/20 rounded-full w-8 h-8 flex items-center justify-center transition-colors cursor-pointer z-20"><i class="fas fa-times"></i></button>
                </div>

                <div class="p-6 text-center">
                    <p class="text-xs text-slate-500 mb-6 leading-relaxed">
                        Bergabunglah untuk mendapatkan infomasi terbaru.
                    </p>
                    <div class="space-y-3">
                        <button @click="joinGroup()" class="w-full py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl shadow-lg flex items-center justify-center gap-2">
                            <span>Gabung Sekarang</span>
                        </button>
                        <button @click="closeModal()" class="text-xs font-bold text-slate-400 hover:text-slate-600 uppercase tracking-wider py-2">
                            Nanti Saja
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@include('mahasiswa.components.modal-reset')