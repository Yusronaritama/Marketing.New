<div class="animate-fade-in-up">
    {{-- Header Section --}}
    <div class="flex items-center gap-3 mb-8 border-b border-slate-200/60 pb-4">
        <div class="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 shadow-sm">
            <i class="fas fa-user text-lg"></i>
        </div>
        <div>
            <h2 class="text-xl font-bold text-slate-800">Data Pribadi</h2>
            <p class="text-xs text-slate-500">Lengkapi identitas diri Anda dengan benar.</p>
        </div>
    </div>
    
    <form id="step1Form" x-on:submit.prevent="submitStep1()">
        @csrf
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {{-- 1. NAMA LENGKAP --}}
            <div class="space-y-2 group">
                <label class="text-xs font-bold text-slate-600 uppercase tracking-wide ml-1">
                    Nama Lengkap <span class="text-red-500">*</span>
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <i class="fas fa-id-card text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                    </div>
                    <input type="text" name="nama" value="{{ $registration->nama ?? auth()->user()->name }}"
                           class="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all shadow-sm"
                           placeholder="Sesuai KTP/Ijazah" required>
                </div>
            </div>
            
            {{-- 2. EMAIL --}}
            <div class="space-y-2 group">
                <label class="text-xs font-bold text-slate-600 uppercase tracking-wide ml-1">
                    Alamat Email <span class="text-red-500">*</span>
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <i class="fas fa-envelope text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                    </div>
                    <input type="email" name="email" value="{{ $registration->gmail ?? auth()->user()->email }}"
                           class="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all shadow-sm"
                           placeholder="contoh@email.com" required>
                </div>
            </div>
            
            {{-- 3. NOMOR TELEPON --}}
            <div class="space-y-2 group">
                <label class="text-xs font-bold text-slate-600 uppercase tracking-wide ml-1">
                    Nomor WhatsApp <span class="text-red-500">*</span>
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <i class="fab fa-whatsapp text-slate-400 group-focus-within:text-green-500 transition-colors text-lg"></i>
                    </div>
                    <input type="tel" name="phone" value="{{ $registration->phone ?? auth()->user()->phone }}"
                           class="w-full pl-11 pr-4 py-3 bg-white border border-slate-200 rounded-xl text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all shadow-sm"
                           placeholder="0812xxxx" required>
                </div>
            </div>
            
            {{-- 4. STATUS PEKERJAAN --}}
            <div class="space-y-2 group">
                <label class="text-xs font-bold text-slate-600 uppercase tracking-wide ml-1">
                    Status Pekerjaan <span class="text-red-500">*</span>
                </label>
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                        <i class="fas fa-briefcase text-slate-400 group-focus-within:text-blue-500 transition-colors"></i>
                    </div>
                    <select name="status_pekerjaan" 
                            class="w-full pl-11 pr-10 py-3 bg-white border border-slate-200 rounded-xl text-slate-700 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all shadow-sm appearance-none cursor-pointer" 
                            required>
                        <option value="" disabled {{ !isset($registration->status_pekerjaan) ? 'selected' : '' }}>-- Pilih Status --</option>
                        <option value="0" {{ isset($registration->status_pekerjaan) && $registration->status_pekerjaan == '0' ? 'selected' : '' }}>Tidak Bekerja</option>
                        <option value="1" {{ isset($registration->status_pekerjaan) && $registration->status_pekerjaan == '1' ? 'selected' : '' }}>Bekerja</option>
                    </select>
                    {{-- Custom Chevron --}}
                    <div class="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none">
                        <i class="fas fa-chevron-down text-xs text-slate-400"></i>
                    </div>
                </div>
            </div>

        </div>
        
        {{-- Navigation Buttons --}}
        <div class="flex justify-end mt-10 pt-6 border-t border-slate-200/60">
            <button type="submit" 
                    class="group relative inline-flex items-center justify-center gap-2 px-8 py-3.5 text-sm font-bold text-white transition-all duration-300 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl hover:from-blue-700 hover:to-indigo-700 hover:shadow-lg hover:shadow-blue-500/30 focus:ring-4 focus:ring-blue-500/20 disabled:opacity-70 disabled:cursor-not-allowed"
                    x-bind:disabled="loading">
                
                <span x-show="!loading" class="flex items-center gap-2">
                    Simpan & Lanjutkan <i class="fas fa-arrow-right transition-transform group-hover:translate-x-1"></i>
                </span>
                
                <span x-show="loading" class="flex items-center gap-2" x-cloak>
                    <svg class="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Menyimpan...
                </span>
            </button>
        </div>
    </form>
</div>

<script>
function submitStep1() {
    // Tampilkan loading state (via Alpine jika ada, atau manual)
    // Asumsi parent component Alpine memiliki variable 'loading'
    
    const form = document.getElementById('step1Form');
    const formData = new FormData(form);
    
    // Opsional: Validasi manual sederhana agar UX lebih cepat
    if(!formData.get('nama') || !formData.get('email') || !formData.get('phone') || !formData.get('status_pekerjaan')) {
        Swal.fire({
            icon: 'warning',
            title: 'Data Belum Lengkap',
            text: 'Mohon lengkapi semua kolom yang bertanda bintang (*).',
            confirmButtonColor: '#3b82f6'
        });
        return;
    }

    fetch('{{ route("mahasiswa.registration.step1") }}', {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Accept': 'application/json',
        },
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 2000,
                timerProgressBar: true,
            });

            Toast.fire({
                icon: 'success',
                title: data.message || 'Data berhasil disimpan'
            }).then(() => {
                window.location.reload();
            });
        } else {
            throw new Error(data.message);
        }
    })
    .catch(error => {
        Swal.fire({
            icon: 'error',
            title: 'Gagal Menyimpan',
            text: error.message || 'Terjadi kesalahan pada server.',
            confirmButtonColor: '#ef4444'
        });
    });
}
</script>