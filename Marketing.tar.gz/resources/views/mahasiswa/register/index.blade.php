@extends('layouts.mahasiswa.register')

@section('title', 'Pendaftaran Mahasiswa Baru')

@section('content')

    {{-- A. WIDGET COUNTDOWN TIMER --}}
    {{-- Hanya muncul jika waktu masih ada & belum completed --}}
   {{-- A. WIDGET COUNTDOWN TIMER --}}
    @if(isset($remainingSeconds) && $remainingSeconds > 0)
        <div x-data="timerApp({{ $remainingSeconds }})" x-init="initTimer()" style="display: none;" x-show="true"
             class="max-w-5xl mx-auto mb-8 relative overflow-hidden rounded-2xl bg-rose-50/80 border border-rose-100 p-5 shadow-lg backdrop-blur-sm ring-1 ring-rose-200 animate-fade-in-down">
            
            <div class="absolute top-0 right-0 -mt-4 -mr-4 h-24 w-24 bg-rose-200/40 rounded-full blur-2xl animate-pulse"></div>

            <div class="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
                <div class="flex items-start gap-4 w-full md:w-auto">
                    <div class="h-12 w-12 rounded-xl bg-white flex items-center justify-center text-rose-500 shadow-sm shrink-0 border border-rose-100">
                        <i class="fas fa-stopwatch text-2xl animate-pulse"></i>
                    </div>
                    <div>
                        <h3 class="text-sm font-extrabold text-rose-800 uppercase tracking-widest mb-1">Sisa Waktu Sesi</h3>
                        <p class="text-xs text-rose-600/90 font-medium leading-relaxed">
                            Selesaikan Sesi ini dalam 3 hari.<br>
                            <span class="bg-rose-100 px-1 rounded text-rose-800 font-bold">Data akan direset otomatis</span> jika waktu habis.
                        </p>
                    </div>
                </div>
                
                {{-- Display Waktu --}}
                <div class="flex items-center gap-3">
                    <div class="flex flex-col items-center">
                        <div class="bg-white border border-rose-100 rounded-xl w-14 h-14 flex items-center justify-center shadow-sm">
                            <span class="text-2xl font-black text-rose-600 tabular-nums" x-text="hours">00</span>
                        </div>
                        <span class="text-[9px] font-bold text-rose-400 uppercase mt-1">Jam</span>
                    </div>
                    <span class="text-rose-300 font-bold text-2xl pb-4">:</span>
                    <div class="flex flex-col items-center">
                        <div class="bg-white border border-rose-100 rounded-xl w-14 h-14 flex items-center justify-center shadow-sm">
                            <span class="text-2xl font-black text-rose-600 tabular-nums" x-text="minutes">00</span>
                        </div>
                        <span class="text-[9px] font-bold text-rose-400 uppercase mt-1">Mnt</span>
                    </div>
                    <span class="text-rose-300 font-bold text-2xl pb-4">:</span>
                    <div class="flex flex-col items-center">
                        <div class="bg-white border border-rose-100 rounded-xl w-14 h-14 flex items-center justify-center shadow-sm relative overflow-hidden">
                            <span class="text-2xl font-black text-rose-600 tabular-nums relative z-10" x-text="seconds">00</span>
                            <div class="absolute bottom-0 left-0 w-full bg-rose-50 transition-all duration-1000 ease-linear" :style="'height: ' + (seconds / 60 * 100) + '%'"></div>
                        </div>
                        <span class="text-[9px] font-bold text-rose-400 uppercase mt-1">Dtk</span>
                    </div>
                </div>
            </div>
            
            {{-- Progress Bar --}}
            <div class="absolute bottom-0 left-0 h-1.5 bg-rose-100 w-full">
                <div class="h-full bg-gradient-to-r from-rose-500 to-red-600 transition-all duration-1000 ease-linear" :style="'width: ' + percent + '%'"></div>
            </div>
        </div>
    @endif

    {{-- B. MAIN APP (STEPPER & CONTENT) --}}
    <div x-data="registrationApp()" x-init="init()" x-cloak>
        
        
       
        {{-- STEPPER NAVIGATION (FIXED LINE LENGTH) --}}
        <div class="mb-8">
            <div class="bg-white/90 backdrop-blur-md rounded-2xl shadow-sm border border-slate-200/60 p-6 sm:p-8">
                
                <div class="relative flex items-start justify-between">
        
                    
                    <div class="absolute top-5 md:top-6 left-0 right-0 mx-5 md:mx-6 -z-10">
                        
                        {{-- Garis Abu-abu (Track) --}}
                        <div class="absolute top-0 left-0 w-full h-1 bg-slate-100 rounded-full"></div>
                        
                        {{-- Garis Biru (Progress) --}}
                        {{-- Karena wrapper sudah dipotong margin, width 100% di sini artinya 100% dari tengah ke tengah --}}
                        <div class="absolute top-0 left-0 h-1 bg-gradient-to-r from-blue-600 to-indigo-500 rounded-full transition-all duration-700 ease-out"
                             x-bind:style="'width: ' + ((currentStep - 1) / 3) * 100 + '%'"></div>
                    </div>
                    
                    {{-- DATA STEPS --}}
                    @php
                        $steps = ['Data Pribadi', 'Pilihan Jurusan', 'Upload Berkas', 'Validasi'];
                        $icons = ['user', 'graduation-cap', 'file-upload', 'check-circle'];
                    @endphp
                    
                    @foreach($steps as $index => $step)
                        <div class="flex flex-col items-center group cursor-pointer w-24 relative" 
                             x-on:click="showStep({{ $index + 1 }})">
                            
                            {{-- LINGKARAN ICON --}}
                            <div class="w-10 h-10 md:w-12 md:h-12 rounded-full flex items-center justify-center transition-all duration-300 border-[3px] z-10 box-border"
                                 x-bind:class="currentStep >= {{ $index + 1 }} 
                                    ? 'bg-blue-600 border-blue-600 text-white shadow-lg shadow-blue-500/40 scale-110' 
                                    : 'bg-white border-slate-200 text-slate-300 group-hover:border-blue-300 group-hover:text-blue-400'">
                                
                                <i class="fas text-xs md:text-sm" 
                                   x-bind:class="currentStep > {{ $index + 1 }} ? 'fa-check' : 'fa-{{ $icons[$index] }}'"></i>
                            </div>
        
                            {{-- LABEL TEKS --}}
                            <span class="mt-3 text-[10px] md:text-[11px] font-bold uppercase tracking-wider text-center leading-tight transition-colors duration-300" 
                                  x-bind:class="currentStep >= {{ $index + 1 }} ? 'text-blue-700' : 'text-slate-400'">
                                {{ $step }}
                            </span>
                        </div>
                    @endforeach
        
                </div>
            </div>
        </div>

        {{-- CONTENT WRAPPER --}}
        <div>
            {{-- INCLUDE FILE BLADE LANGSUNG (Pastikan file ada di folder steps) --}}
            <div x-show="currentStep === 1" class="animate-fade-in-up">
                @include('mahasiswa.register.steps.step1')
            </div>
            <div x-show="currentStep === 2" x-cloak class="animate-fade-in-up">
                @include('mahasiswa.register.steps.step2')
            </div>
            <div x-show="currentStep === 3" x-cloak class="animate-fade-in-up">
                @include('mahasiswa.register.steps.step3')
            </div>
            <div x-show="currentStep === 4" x-cloak class="animate-fade-in-up">
                @include('mahasiswa.register.steps.step4')
            </div>
        </div>
    </div>

    {{-- MAIN LOGIC SCRIPT --}}
    <script>
    function registrationApp() {
        return {
            // ============================================================
            // 1. STATE & PROPERTIES
            // ============================================================
            jurusan1: '{{ $registration->jurusan1 }}',
            jurusan2: '{{ $registration->jurusan2 }}',
            currentStep: {{ $registration->step_completed + 1 }},
            loading: false,
            scanning: false,
            
            // [BARU] Variable untuk melacak status upload agar UI bereaksi real-time
            filesUploaded: {}, 

            scanStatus: {
                scan_status: 'not_scanned',
                scan_results: {},
                jalur_pendaftaran: '{{ $registration->jalur_pendaftaran }}'
            },
            
            // ============================================================
            // 2. INITIALIZATION
            // ============================================================
            init() {
                console.log('Registration App Initialized. Current Step:', this.currentStep);
                
                // Cek file yang mungkin sudah ada saat reload (Browser caching)
                this.$nextTick(() => {
                    document.querySelectorAll('input[type="file"]').forEach(input => {
                        if (input.files.length > 0) {
                            this.handleFileChange(input.id);
                        }
                    });
                });

                if (this.currentStep === 3) {
                    this.$nextTick(() => { this.checkScanStatus(); });
                }
            },

            // ============================================================
            // 3. NAVIGATION & STEPPER
            // ============================================================
            showStep(stepNumber) {
                if (stepNumber <= {{ $registration->step_completed }} + 1) {
                    this.currentStep = stepNumber;
                    if (stepNumber === 3) this.$nextTick(() => { this.checkScanStatus(); });
                }
            },
            previousStep() {
                if (this.currentStep > 1) this.currentStep--;
            },
            
            // ============================================================
            // 4. HELPER FUNCTIONS (FILE HANDLING) - DIPERBAIKI
            // ============================================================
            
            // [FIX] Cek dari reactive state DULU, baru cek DOM
            hasFile(inputId) {
                // Jika status reactive true, return true (UI langsung update)
                if (this.filesUploaded[inputId]) return true;
                
                // Fallback: Cek manual elemen input (untuk load awal)
                const input = document.getElementById(inputId);
                return input && input.files && input.files.length > 0;
            },

            formatBytes(bytes, decimals = 2) {
                if (bytes === 0) return '0 Bytes';
                const k = 1024;
                const dm = decimals < 0 ? 0 : decimals;
                const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
                const i = Math.floor(Math.log(bytes) / Math.log(k));
                return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
            },

            handleFileChange(fileType) {
                // 1. [MOBILE FIX] Gunakan setTimeout agar browser tidak crash/blank di HP
                setTimeout(() => {
                    const input = document.getElementById(fileType);
                    const displayElement = document.getElementById(fileType + '_name');
                    
                    if (input && input.files && input.files[0]) {
                        const file = input.files[0];
                        
                        // 2. [VALIDASI PDF] Cek tipe file
                        if (file.type !== 'application/pdf') {
                            Swal.fire({
                                icon: 'error',
                                title: 'Format Salah',
                                text: 'Mohon upload file bertipe PDF.',
                                confirmButtonColor: '#e11d48'
                            });
                            
                            // Reset Input jika salah
                            input.value = ''; 
                            
                            // Hapus status file dari Alpine
                            const newFiles = { ...this.filesUploaded };
                            delete newFiles[fileType];
                            this.filesUploaded = newFiles;

                            // Kosongkan tampilan nama
                            if (displayElement) displayElement.innerHTML = '';
                            
                            return; // Stop proses
                        }

                        // 3. [LOGIKA ASLI ANDA] Ambil Nama & Size
                        const fileName = file.name;
                        const fileSize = this.formatBytes(file.size);

                        // Update Tampilan HTML
                        if (displayElement) {
                            displayElement.innerHTML = `
                                <div class="flex flex-col items-center justify-center animate-fade-in-up">
                                    <span class="line-clamp-1 break-all text-xs font-bold text-slate-700 text-center">${fileName}</span>
                                    <span class="mt-1 px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 text-[10px] font-bold border border-emerald-200 shadow-sm">
                                        <i class="fas fa-hdd mr-1"></i> ${fileSize}
                                    </span>
                                </div>
                            `;
                        }
                        
                        // Update State Reactive agar x-show muncul
                        this.filesUploaded = { ...this.filesUploaded, [fileType]: true };
                        
                        // Reset status scan
                        this.scanStatus.scan_status = 'not_scanned';
                    }
                }, 150); // Delay 150ms sangat penting untuk Mobile
            },
            
            // ============================================================
            // 5. STEP 1 SUBMISSION (DATA DIRI)
            // ============================================================
            async submitStep1() {
                const form = document.getElementById('step1Form');
                if (!form) return;
                this.loading = true;
                const formData = new FormData(form);
                try {
                    const response = await fetch('{{ route("mahasiswa.registration.step1") }}', {
                        method: 'POST',
                        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}', 'Accept': 'application/json' },
                        body: formData
                    });
                    const data = await response.json();
                    if (data.success) {
                        Swal.fire({icon: 'success', title: 'Berhasil!', text: data.message, timer: 1500, showConfirmButton: false})
                            .then(() => window.location.reload());
                    } else throw new Error(data.message);
                } catch (error) {
                    Swal.fire({icon: 'error', title: 'Error', text: error.message});
                } finally { this.loading = false; }
            },
            
            // ============================================================
            // 6. STEP 2 SUBMISSION (JURUSAN)
            // ============================================================
            async submitStep2() {
                const form = document.getElementById('step2Form'); 
                if (!form) return; 
                this.loading = true;
                const formData = new FormData(form);
                try {
                    const response = await fetch('{{ route("mahasiswa.registration.step2") }}', {
                        method: 'POST',
                        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}', 'Accept': 'application/json' },
                        body: formData
                    });
                    const data = await response.json();
                    if (data.success) {
                        Swal.fire({icon: 'success', title: 'Berhasil!', text: data.message, timer: 1500, showConfirmButton: false})
                            .then(() => window.location.reload());
                    } else throw new Error(data.message);
                } catch (error) {
                    Swal.fire({icon: 'error', title: 'Error', text: error.message});
                } finally { this.loading = false; }
            },

            // ============================================================
            // 7. STEP 3 LOGIC (UPLOAD & SCAN)
            // ============================================================
            async checkScanStatus() {
                try {
                    const response = await fetch('/mahasiswa/scanner/status', {
                        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}', 'Accept': 'application/json' }
                    });
                    const data = await response.json();
                    if (data.success) this.scanStatus = data;
                } catch (error) { console.error(error); }
            },

            async scanAndValidate() {
                if (this.scanning) return;
                this.scanning = true;
                
                window.dispatchEvent(new CustomEvent('pause-timer'));

                try {
                    const form = document.getElementById('step3Form');
                    const fileInputs = form.querySelectorAll('input[type="file"][required]');
                    let allFilesUploaded = true;
                    fileInputs.forEach(input => { if (!input.files || input.files.length === 0) allFilesUploaded = false; });
                    
                    if (!allFilesUploaded) throw new Error('Harap upload semua berkas wajib sebelum melakukan validasi.');
                    
                    const formData = new FormData(form);
                    
                    const response = await fetch('/mahasiswa/scanner/scan-temp', {
                        method: 'POST', headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }, body: formData
                    });
                    const data = await response.json();
                    
                    if (data.success) {
                        this.scanStatus = {
                            scan_status: data.scan_status,
                            scan_results: data.scan_results,
                            jalur_pendaftaran: data.jalur_pendaftaran
                        };
                        if (data.scan_status === 'completed') {
                            Swal.fire({icon: 'success', title: 'Valid!', text: 'Semua berkas valid.', timer: 2000, showConfirmButton: false});
                        } else {
                            Swal.fire({icon: 'warning', title: 'Perhatian', text: 'Beberapa berkas perlu diperbaiki.', confirmButtonColor: '#f59e0b'});
                        }
                    } else throw new Error(data.message);
                } catch (error) {
                    Swal.fire({icon: 'error', title: 'Gagal', text: error.message});
                } finally { 
                    this.scanning = false;
                    window.dispatchEvent(new CustomEvent('resume-timer'));
                }
            },

            async submitStep3() {
                this.loading = true;
                const form = document.getElementById('step3Form');
                const formData = new FormData(form);
                formData.append('scan_results', JSON.stringify(this.scanStatus.scan_results));
                formData.append('scan_status', this.scanStatus.scan_status);
                try {
                    const response = await fetch('{{ route("mahasiswa.registration.step3") }}', {
                        method: 'POST', headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }, body: formData
                    });
                    const data = await response.json();
                    if (data.success) {
                        Swal.fire({icon: 'success', title: 'Berhasil!', text: data.message, timer: 2000, showConfirmButton: false})
                            .then(() => window.location.reload());
                    } else throw new Error(data.message);
                } catch (error) {
                    Swal.fire({icon: 'error', title: 'Gagal', text: error.message});
                } finally { this.loading = false; }
            },
            
            canProceedToNextStep() {
                if (this.loading || this.scanning) return false;
                const form = document.getElementById('step3Form');
                if(form) {
                     const fileInputs = form.querySelectorAll('input[type="file"][required]');
                     for (let input of fileInputs) {
                         if (!input.files || input.files.length === 0) return false;
                     }
                }
                return true;
            },

            // --- TAMPILAN VIEW STATUS ---
            getStatusText(status) {
                const map = {'not_scanned': 'Belum Divalidasi', 'scanning': 'Sedang Memindai...', 'completed': 'Validasi Selesai', 'partial_failed': 'Perlu Perbaikan', 'failed': 'Validasi Gagal'};
                return map[status] || status;
            },
            getFileName(fileType) {
                const map = {
                    'file_ktp': 'KTP', 
                    'file_kk': 'Kartu Keluarga', 
                    'file_ijazah': 'Ijazah/SKL', 
                    'file_transkrip_nilai': 'Transkrip Nilai', 
                    'file_surat_pindah': 'Surat Pindah',
                    'file_ktm': 'KTM Asal',
                    'file_ijazah_s1': 'Ijazah S1',
                    'file_transkrip_s1': 'Transkrip S1',
                    'file_surat_tugas_kerja': 'Surat Tugas Kerja',
                    'file_transkrip_nilai_rpl': 'Transkrip RPL',
                    'file_surat_buta_warna': 'Surat Buta Warna',
                    'file_surat_akademik_ekstensi': 'Transkrip Nilai (Ekstensi)'
                };
                return map[fileType] || fileType.replace('file_', '').replace(/_/g, ' ').toUpperCase();
            },

            // ============================================================
            // 8. STEP 4: FINALISASI
            // ============================================================
            completeRegistration() {
                Swal.fire({
                    title: '<span class="text-xl font-bold text-slate-800">Konfirmasi Akhir</span>',
                    html: `<div class="mt-2 mb-4"><p class="text-sm text-slate-600">Yakin data sudah benar?</p></div>
                           <div class="bg-amber-50 border border-amber-100 rounded-xl p-3 text-left flex gap-3">
                               <div class="shrink-0 text-amber-500 mt-0.5"><i class="fas fa-exclamation-triangle"></i></div>
                               <div><p class="text-xs font-bold text-amber-800">Peringatan:</p><p class="text-xs text-amber-700">Data akan dikunci permanen setelah ini.</p></div>
                           </div>`,
                    icon: null, showCancelButton: true, confirmButtonColor: '#10b981', cancelButtonColor: '#94a3b8',
                    confirmButtonText: 'Ya, Selesaikan!', cancelButtonText: 'Cek Lagi', reverseButtons: true,
                    customClass: { popup: 'rounded-2xl font-sans', confirmButton: 'rounded-xl px-6 py-2.5 font-bold', cancelButton: 'rounded-xl px-6 py-2.5 font-bold' }
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.loading = true;
                        fetch('{{ route("mahasiswa.registration.complete") }}', {
                            method: 'POST',
                            headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}', 'Accept': 'application/json', 'Content-Type': 'application/json' },
                            body: JSON.stringify({ scan_results: this.scanStatus ? this.scanStatus.scan_results : {} })
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                Swal.fire({icon: 'success', title: 'Selesai!', text: 'Pendaftaran berhasil.', timer: 3000, showConfirmButton: false})
                                    .then(() => { window.location.href = '{{ route("mahasiswa.dashboard") }}'; });
                            } else throw new Error(data.message);
                        })
                        .catch(error => {
                            this.loading = false;
                            Swal.fire({icon: 'error', title: 'Kesalahan', text: error.message});
                        });
                    }
                });
            }
        };
    }
    
    // ============================================================
    // 9. TIMER LOGIC (GLOBAL SCOPE)
    // ============================================================
    function timerApp(initialSeconds) {
        const TOTAL_3_DAYS = 259200; 

        return {
            totalOrigin: TOTAL_3_DAYS, 
            remaining: initialSeconds,
            hours: '00', minutes: '00', seconds: '00', percent: 100, interval: null,
            paused: false,

            initTimer() {
                if (this.remaining <= 0) this.remaining = this.totalOrigin;
                this.updateDisplay();
                
                window.addEventListener('pause-timer', () => { this.paused = true; });
                window.addEventListener('resume-timer', () => { this.paused = false; });

                this.interval = setInterval(() => {
                    if (!this.paused) {
                        this.remaining--;
                        this.updateDisplay();
                        
                        let p = (this.remaining / this.totalOrigin) * 100;
                        this.percent = p < 0 ? 0 : p;

                        if (this.remaining <= 0) {
                            clearInterval(this.interval);
                            this.timeIsUp();
                        }
                    }
                }, 1000);
            },
            
            updateDisplay() {
                if (this.remaining < 0) this.remaining = 0;
                const h = Math.floor(this.remaining / 3600);
                const m = Math.floor((this.remaining % 3600) / 60);
                const s = this.remaining % 60;
                this.hours = String(h).padStart(2, '0');
                this.minutes = String(m).padStart(2, '0');
                this.seconds = String(s).padStart(2, '0');
            },
            
            timeIsUp() {
                Swal.fire({
                    icon: 'error', title: 'Waktu Habis!',
                    text: 'Sesi pendaftaran Anda telah berakhir dan data akan direset.',
                    allowOutsideClick: false, confirmButtonText: 'Muat Ulang', confirmButtonColor: '#e11d48'
                }).then(() => { window.location.reload(); });
            }
        }
    }
</script>   
@endsection