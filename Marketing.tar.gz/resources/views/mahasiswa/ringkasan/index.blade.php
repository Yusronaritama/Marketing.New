@extends('layouts.mahasiswa.app')

@section('title', 'Manifest Data Pendaftaran')

@section('content')

@php
    // --- 1. SETUP VARIABEL DARI CONTROLLER ---
    $biodata   = $biodata ?? null;
    $billing   = $billing ?? null; // SlikBilling object
    $dataFinal = $dataFinal ?? null;
    $ereg      = $ereg ?? null;
    $user      = $user ?? Auth::user();
    
    // --- 2. LOGIKA STATUS KELULUSAN (STRICT DARI CONTROLLER) ---
    // Mengambil $statusUjian yang dikirim RingkasanController
    // Nilainya bisa: 'Lulus', 'Tidak Lulus', 'Menunggu Hasil', atau 'Belum Ujian'
    $statusText = $statusUjian ?? 'Belum Ujian';
    
    // Normalisasi ke Huruf Besar untuk pengecekan
    $statusUpper = strtoupper($statusText);

    $isLulus = $statusUpper === 'LULUS';
    $isGagal = $statusUpper === 'TIDAK LULUS' || $statusUpper === 'GAGAL';
    
    // --- 3. STATUS KEUANGAN ---
    // Cek $slikBillingStatus yang dikirim controller
    $lunas = (isset($slikBillingStatus) && $slikBillingStatus == 'paid');
@endphp

<div class="max-w-6xl mx-auto pb-20 px-4 font-sans text-slate-800">

    {{-- WRAPPER UTAMA DENGAN ALPINE DATA --}}
<div x-data="{ showAlmetModal: false }">

    {{-- HEADER & ACTIONS (LIGHT NAVBAR) --}}
    <div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4 print:hidden bg-white p-5 rounded-2xl border border-slate-200 shadow-sm relative z-20">
        <div>
            <h1 class="text-2xl font-black text-slate-800 tracking-tighter uppercase flex items-center gap-2">
                <i class="fas fa-file-contract text-blue-600"></i> Admission Manifest
            </h1>
            <p class="text-slate-500 text-xs font-mono tracking-widest uppercase">
                Document Ref: #{{ $ereg->trx_id ?? 'PENDING' }}
            </p>
        </div>

        <div class="flex flex-wrap justify-end gap-3">
            {{-- 1. Tombol Dashboard --}}
            <a href="{{ route('mahasiswa.dashboard') }}" class="px-4 py-2 rounded-lg bg-slate-50 border border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-blue-600 text-xs font-bold uppercase tracking-wider shadow-sm transition">
                <i class="fas fa-chevron-left mr-1"></i> Dashboard
            </a>

            {{-- 2. TOMBOL PILIH ALMAMATER (BARU) --}}
            {{-- Hanya muncul jika sudah lulus (Opsional, hapus @if jika ingin selalu muncul) --}}
            @if($isLulus) 
                <button @click="showAlmetModal = true" 
                        class="px-5 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 text-xs font-bold uppercase tracking-wider shadow-md shadow-indigo-200 transition flex items-center gap-2">
                    <i class="fas fa-tshirt"></i> 
                    <span>
                        {{ $ereg->ukuran_almamater ? 'Almet: '.$ereg->ukuran_almamater : 'Pilih Almet' }}
                    </span>
                </button>
            @endif

            {{-- 3. Tombol Cetak Surat Lulus --}}
            @if($isLulus)
                <a href="{{ route('mahasiswa.surat.download') }}" target="_blank" class="px-5 py-2 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 text-xs font-bold uppercase tracking-wider shadow-md shadow-emerald-200 transition flex items-center gap-2">
                    <i class="fas fa-certificate"></i> Surat Lulus
                </a>
            @else
                <button disabled class="px-5 py-2 rounded-lg bg-slate-200 text-slate-400 text-xs font-bold uppercase tracking-wider cursor-not-allowed flex items-center gap-2 opacity-70" title="Status Kelulusan: {{ $statusText }}">
                    <i class="fas fa-certificate"></i> Surat Lulus
                </button>
            @endif

            {{-- 4. Tombol Print --}}
            <a href="{{ route('mahasiswa.print') }}" target="_blank" class="px-5 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 text-xs font-bold uppercase tracking-wider shadow-md shadow-blue-200 transition flex items-center gap-2">
                <i class="fas fa-file-pdf"></i> Cetak Bukti Daftar
            </a>
        </div>
    </div>

    {{-- ========================================================= --}}
    {{-- MODAL PILIH UKURAN ALMET (POPUP) --}}
    {{-- ========================================================= --}}
    <div x-show="showAlmetModal" style="display: none;" 
         class="fixed inset-0 z-[999] flex items-center justify-center px-4" x-cloak>
        
        {{-- Backdrop Gelap --}}
        <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" 
             @click="showAlmetModal = false"
             x-transition:enter="ease-out duration-300" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100"
             x-transition:leave="ease-in duration-200" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0">
        </div>

        {{-- Konten Modal --}}
        <div class="bg-white rounded-2xl shadow-2xl max-w-md w-full relative z-10 overflow-hidden transform transition-all"
             x-transition:enter="ease-out duration-300" x-transition:enter-start="opacity-0 scale-95 translate-y-4" x-transition:enter-end="opacity-100 scale-100 translate-y-0"
             x-transition:leave="ease-in duration-200" x-transition:leave-start="opacity-100 scale-100 translate-y-0" x-transition:leave-end="opacity-0 scale-95 translate-y-4">
            
            {{-- Header Modal --}}
            <div class="bg-gradient-to-r from-indigo-600 to-purple-600 p-5 text-white text-center relative">
                <button @click="showAlmetModal = false" class="absolute top-4 right-4 text-white/70 hover:text-white transition">
                    <i class="fas fa-times text-xl"></i>
                </button>
                <div class="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-3 backdrop-blur-md">
                    <i class="fas fa-tshirt text-3xl"></i>
                </div>
                <h3 class="text-xl font-bold">Pilih Ukuran Almamater</h3>
                <p class="text-indigo-100 text-xs mt-1">Pastikan ukuran sesuai, data akan disimpan.</p>
            </div>

            {{-- Body Modal (Form) --}}
            <div class="p-6">
                <form action="{{ route('mahasiswa.ringkasan.simpan_almet') }}" method="POST">
                    @csrf
                    
                    {{-- Grid Pilihan Ukuran --}}
                    <div class="grid grid-cols-3 gap-3 mb-6">
                        @foreach(['S', 'M', 'L', 'XL', 'XXL', 'XXXL', '4XL', '5XL', '6XL'] as $size)
                            <label class="cursor-pointer group relative">
                                <input type="radio" name="ukuran_almamater" value="{{ $size }}" class="peer sr-only" 
                                    {{ ($ereg->ukuran_almamater ?? '') == $size ? 'checked' : '' }}>
                                
                                <div class="p-3 rounded-xl border-2 border-slate-200 text-center transition-all duration-200
                                            hover:border-indigo-400 hover:bg-indigo-50
                                            peer-checked:border-indigo-600 peer-checked:bg-indigo-600 peer-checked:text-white peer-checked:shadow-lg">
                                    <span class="block text-lg font-bold">{{ $size }}</span>
                                </div>
                            </label>
                        @endforeach
                    </div>
                    
                    {{-- Opsi Jumbo Terpisah (Optional) --}}
                    <div class="mb-6">
                        <label class="cursor-pointer group relative block">
                            <input type="radio" name="ukuran_almamater" value="JUMBO" class="peer sr-only"
                                {{ ($ereg->ukuran_almamater ?? '') == 'JUMBO' ? 'checked' : '' }}>
                        </label>
                    </div>

                    <button type="submit" class="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl shadow-lg transition transform active:scale-95">
                        Simpan Ukuran
                    </button>
                </form>
            </div>
        </div>
    </div>

</div>

    {{-- MANIFEST CARD CONTAINER (TETAP PUTIH) --}}
    <div id="print-container" class="bg-white rounded-xl overflow-hidden shadow-2xl border border-slate-200 relative">
        
        {{-- Background Pattern --}}
        <div class="absolute inset-0 opacity-[0.03] pointer-events-none print:hidden" 
             style="background-image: repeating-linear-gradient(45deg, #000 25%, transparent 25%, transparent 75%, #000 75%, #000), repeating-linear-gradient(45deg, #000 25%, #fff 25%, #fff 75%, #000 75%, #000); background-position: 0 0, 10px 10px; background-size: 20px 20px;">
        </div>

        {{-- LAYOUT UTAMA --}}
        <div class="flex flex-col lg:flex-row relative z-10 print-table-row">

            {{-- ================================================= --}}
            {{-- KOLOM KIRI: SIDEBAR                               --}}
            {{-- ================================================= --}}
            <div id="print-sidebar" class="lg:w-[320px] bg-slate-50 p-8 border-r border-slate-200 flex flex-col items-center text-center relative">
                
                {{-- STAMP STATUS --}}
                @if($isLulus)
                    <div class="absolute top-6 left-6 z-20 transform -rotate-12 border-4 border-green-600 text-green-600 px-3 py-1 text-xl font-black uppercase tracking-widest opacity-80 mix-blend-multiply pointer-events-none">
                        ACCEPTED
                    </div>
                @elseif($isGagal)
                    <div class="absolute top-6 left-6 z-20 transform -rotate-12 border-4 border-red-600 text-red-600 px-3 py-1 text-xl font-black uppercase tracking-widest opacity-80 pointer-events-none">
                        REJECTED
                    </div>
                @endif

                {{-- FOTO PROFIL --}}
                <div class="relative w-40 h-40 mb-6 group">
                    <div class="absolute inset-0 bg-blue-200 rounded-full blur-xl opacity-0 group-hover:opacity-50 transition-opacity print:hidden"></div>
                    <div class="w-full h-full rounded-full overflow-hidden border-4 border-white shadow-lg relative z-10 ring-1 ring-slate-200 print:shadow-none print:border-slate-300">
                        @if($user->profile_photo_path)
                            @php $foto = Str::startsWith($user->profile_photo_path, 'http') ? $user->profile_photo_path : asset('storage/' . $user->profile_photo_path); @endphp
                            <img src="{{ $foto }}" class="w-full h-full object-cover">
                        @else
                            <div class="w-full h-full bg-slate-100 flex items-center justify-center text-4xl text-slate-400 font-bold">
                                {{ strtoupper(substr($user->name, 0, 1)) }}
                            </div>
                        @endif
                    </div>
                </div>

                {{-- NAMA & KONTAK --}}
                <h2 class="text-xl font-bold text-slate-800 mb-1 leading-tight">{{ optional($dataFinal)->nama_mahasiswa ?? $biodata->nama_lengkap ?? $user->name }}</h2>
                <p class="text-blue-600 text-xs font-mono mb-1 font-semibold print:text-black">{{ $user->email }}</p>
                <p class="text-slate-500 text-xs font-mono mb-8 pb-8 border-b border-slate-200 w-full print:text-black">{{ optional($dataFinal)->handphone ?? $ereg->phone ?? '-' }}</p>

                {{-- AUTHORIZATION AREA --}}
                <div class="w-full mt-auto">
                    <p class="text-[10px] text-slate-400 uppercase tracking-widest font-bold mb-3 print:text-black">Disahkan Oleh</p>
                    
                    {{-- Logo Kampus --}}
                    <div class="relative h-20 w-full flex items-center justify-center mb-3">
                        <img src="{{ asset('images/logo_ubp.png') }}" 
                             alt="Official Stamp" 
                             class="h-full w-auto object-contain opacity-90 grayscale-[20%] drop-shadow-sm">
                    </div>

                    <p class="text-sm font-bold text-slate-800">Panitia PMB</p>
                    <p class="text-[10px] text-slate-500 uppercase print:text-black">Universitas Buana Perjuangan</p>
                    
                    <div class="mt-4 bg-blue-50 py-1.5 px-3 rounded text-[9px] text-blue-600 border border-blue-100 inline-block font-mono font-semibold print:bg-white print:border-slate-400 print:text-black">
                        <i class="fas fa-shield-alt mr-1"></i> Officially Verified: {{ date('d M Y') }}
                    </div>
                </div>
            </div>

            {{-- ================================================= --}}
            {{-- KOLOM KANAN: KONTEN                               --}}
            {{-- ================================================= --}}
            <div id="print-content" class="flex-1 bg-white">
                
                {{-- 1. STATUS GRID --}}
                <div class="grid grid-cols-2 md:grid-cols-4 border-b border-slate-200 divide-x divide-slate-200 bg-slate-50 text-center print:bg-white print:border-black print:divide-black">
                    {{-- Biodata --}}
                    <div class="p-4">
                        <span class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 print:text-black">Biodata</span>
                        @if($biodata && $biodata->status_bio == 'completed')
                            <span class="text-green-600 font-black text-sm flex items-center justify-center gap-1 print:text-black"><i class="fas fa-check"></i> VALID</span>
                        @else
                            <span class="text-red-500 font-black text-sm flex items-center justify-center gap-1 print:text-black"><i class="fas fa-times"></i> EMPTY</span>
                        @endif
                    </div>
                    {{-- Ujian --}}
                    <div class="p-4">
                        <span class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 print:text-black">Seleksi</span>
                        @if($isLulus)
                            <span class="text-green-600 font-black text-sm print:text-black">LULUS</span>
                        @elseif($isGagal)
                            <span class="text-red-600 font-black text-sm print:text-black">GAGAL</span>
                        @else
                            <span class="text-amber-500 font-black text-sm print:text-black">{{ strtoupper($statusText) }}</span>
                        @endif
                    </div>
                    {{-- Bayar --}}
                    <div class="p-4">
                        <span class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 print:text-black">Keuangan</span>
                        @if($lunas)
                            <span class="text-green-600 font-black text-sm print:text-black">LUNAS</span>
                        @else
                            <span class="text-orange-500 font-black text-sm print:text-black">TAGIHAN</span>
                        @endif
                    </div>
                    {{-- Final --}}
                    <div class="p-4">
                        <span class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1 print:text-black">PDDIKTI</span>
                        @if($dataFinal)
                            <span class="text-purple-600 font-black text-sm print:text-black">SIAP</span>
                        @else
                            <span class="text-slate-400 font-black text-sm print:text-black">BELUM</span>
                        @endif
                    </div>
                </div>

                {{-- 2. TABEL DATA RINCI --}}
                <div class="p-8 space-y-8 print:p-6 print:space-y-6">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 print:grid print:grid-cols-2 print:gap-6">
                        
                        {{-- GROUP: DATA PRIBADI --}}
                        <div>
                            <h4 class="text-blue-700 text-xs font-bold uppercase tracking-widest mb-4 border-l-4 border-blue-600 pl-3 print:text-black print:border-black">
                                Data Pribadi
                            </h4>
                            <div class="space-y-3">
                                <div class="group">
                                    <span class="block text-[10px] text-slate-500 uppercase font-bold print:text-black">NIK (KTP)</span>
                                    <span class="block text-sm text-slate-800 font-mono font-semibold border-b border-slate-100 pb-1 print:border-slate-300">
                                        {{ optional($dataFinal)->nik ?? $biodata->nik ?? '-' }}
                                    </span>
                                </div>
                                <div class="group">
                                    <span class="block text-[10px] text-slate-500 uppercase font-bold print:text-black">Tempat, Tanggal Lahir</span>
                                    <span class="block text-sm text-slate-800 font-mono font-semibold border-b border-slate-100 pb-1 print:border-slate-300">
                                        {{ optional($dataFinal)->tempat_lahir ?? $biodata->tempat_lahir ?? '-' }}, 
                                        {{ isset($dataFinal->tanggal_lahir) ? $dataFinal->tanggal_lahir->format('d F Y') : (isset($biodata->tanggal_lahir) ? \Carbon\Carbon::parse($biodata->tanggal_lahir)->format('d F Y') : '-') }}
                                    </span>
                                </div>
                                <div class="group">
                                    <span class="block text-[10px] text-slate-500 uppercase font-bold print:text-black">Alamat Domisili</span>
                                    <span class="block text-sm text-slate-800 font-mono font-semibold border-b border-slate-100 pb-1 leading-relaxed print:border-slate-300">
                                        {{ $dataFinal ? ($dataFinal->jalan . ', RT ' . $dataFinal->rt . '/RW ' . $dataFinal->rw . ', ' . $dataFinal->kelurahan) : ($biodata->alamat ?? '-') }}
                                    </span>
                                </div>
                            </div>
                        </div>

                        {{-- GROUP: DATA ORANG TUA --}}
                        <div>
                            <h4 class="text-blue-700 text-xs font-bold uppercase tracking-widest mb-4 border-l-4 border-blue-600 pl-3 print:text-black print:border-black">
                                Data Orang Tua
                            </h4>
                            <div class="space-y-3">
                                <div class="group">
                                    <span class="block text-[10px] text-slate-500 uppercase font-bold print:text-black">Nama Ayah</span>
                                    <span class="block text-sm text-slate-800 font-mono font-semibold border-b border-slate-100 pb-1 print:border-slate-300">
                                        {{ $biodata->nama_ayah ?? '-' }}
                                    </span>
                                </div>
                                <div class="group">
                                    <span class="block text-[10px] text-slate-500 uppercase font-bold print:text-black">Nama Ibu</span>
                                    <span class="block text-sm text-slate-800 font-mono font-semibold border-b border-slate-100 pb-1 print:border-slate-300">
                                        {{ $biodata->nama_ibu ?? '-' }}
                                    </span>
                                </div>
                                <div class="group">
                                    <span class="block text-[10px] text-slate-500 uppercase font-bold print:text-black">Kontak Orang Tua</span>
                                    <span class="block text-sm text-slate-800 font-mono font-semibold border-b border-slate-100 pb-1 print:border-slate-300">
                                        {{ $biodata->dataFinal->handphone ?? '-' }}
                                    </span>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4 border-t border-slate-100 print:grid print:grid-cols-2 print:gap-6 print:border-slate-300">
                        
                        {{-- GROUP: DATA PENDIDIKAN --}}
                        <div>
                            <h4 class="text-blue-700 text-xs font-bold uppercase tracking-widest mb-4 border-l-4 border-blue-600 pl-3 print:text-black print:border-black">
                                Data Pendidikan
                            </h4>
                            <div class="space-y-3">
                                <div class="group">
                                    <span class="block text-[10px] text-slate-500 uppercase font-bold print:text-black">Asal Sekolah</span>
                                    <span class="block text-sm text-slate-800 font-mono font-semibold border-b border-slate-100 pb-1 print:border-slate-300">
                                        {{ $biodata->asal_sekolah ?? '-' }}
                                    </span>
                                </div>
                                <div class="group">
                                    <span class="block text-[10px] text-slate-500 uppercase font-bold print:text-black">Tahun Lulus</span>
                                    <span class="block text-sm text-slate-800 font-mono font-semibold border-b border-slate-100 pb-1 print:border-slate-300">
                                        {{ $biodata->tahun_lulus ?? '-' }}
                                    </span>
                                </div>
                            </div>
                        </div>

                        {{-- GROUP: PILIHAN PROGRAM STUDI --}}
                        <div>
                            <h4 class="text-blue-700 text-xs font-bold uppercase tracking-widest mb-4 border-l-4 border-blue-600 pl-3 print:text-black print:border-black">
                                Program Studi
                            </h4>
                            <div class="space-y-3">
                                <div class="group">
                                    <span class="block text-[10px] text-slate-500 uppercase font-bold print:text-black">Status Akhir</span>
                                    @if($isLulus && isset($jurusanDiterima) && $jurusanDiterima !== '-')
                                        <div class="mt-1 flex items-center gap-2">
                                            <span class="text-sm text-green-700 font-bold font-mono border-b-2 border-green-500 pb-0.5 print:text-black print:border-black">
                                                {{ $jurusanDiterima }}
                                            </span>
                                            <span class="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded font-bold uppercase border border-green-200 print:border-black print:bg-white print:text-black">Diterima</span>
                                        </div>
                                    @else
                                        <div class="flex flex-col gap-1 border-b border-slate-100 pb-2 print:border-slate-300">
                                            <span class="block text-sm text-slate-700 font-mono font-semibold print:text-black">1. {{ $ereg->jurusan1_nama ?? '-' }}</span>
                                            <span class="block text-sm text-slate-500 font-mono print:text-black">2. {{ $ereg->jurusan2_nama ?? '-' }}</span>
                                        </div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        
                        {{-- GELOMBANG (BARU) --}}
                                <div class="group">
                                    <span class="block text-[10px] text-slate-500 uppercase font-bold print:text-black">Gelombang Pendaftaran</span>
                                    <span class="block text-sm text-slate-800 font-mono font-semibold border-b border-slate-100 pb-1 print:border-slate-300">
                                        {{-- Ambil dari relasi master_user di EREG atau Biodata --}}
                                        {{ $ereg->masterUser->gelombang ?? 'Gelombang Tidak Diketahui' }}
                                    </span>
                                </div>

                    </div>

                    {{-- FOOTER: PAYMENT --}}
                    @if($billing)
                    <div class="mt-4 bg-blue-50/50 rounded-2xl p-4 md:p-6 border border-blue-100 flex flex-col md:flex-row md:items-center justify-between gap-4 print:bg-white print:border-slate-400 print:mt-6">
                        {{-- Bagian Kiri: VA Number --}}
                        <div class="flex flex-col">
                            <span class="text-[10px] text-blue-500 uppercase font-black tracking-widest block mb-1 print:text-black">
                                Payment VA Number
                            </span>
                            <div class="flex items-center gap-2 group">
                                <span class="text-xl md:text-2xl font-mono font-black text-blue-900 tracking-wider print:text-black leading-none">
                                    {{ $billing->virtual_account }}
                                </span>
                                {{-- Badge Indikator Kecil --}}
                                <span class="hidden md:inline-block px-1.5 py-0.5 rounded bg-blue-100 text-[8px] font-bold text-blue-600 uppercase print:hidden">
                                    Virtual Account
                                </span>
                            </div>
                        </div>
                    
                        {{-- Garis Pemisah Mobile Only --}}
                        <div class="h-px w-full bg-blue-100 md:hidden print:hidden"></div>
                    
                        {{-- Bagian Kanan: Nominal & Status --}}
                        <div class="flex flex-col md:items-end justify-center">
                            <span class="text-[10px] text-slate-500 uppercase font-black tracking-widest block mb-1 print:text-black">
                                Total Nominal & Status
                            </span>
                            <div class="flex items-center gap-3 md:justify-end">
                                <span class="text-lg md:text-xl font-mono font-black text-slate-800 print:text-black leading-none">
                                    Rp {{ number_format($billing->amount, 0, ',', '.') }}
                                </span>
                                
                                {{-- Status Badge --}}
                                @if($lunas)
                                    <span class="inline-flex items-center gap-1.5 bg-emerald-500 text-white text-[10px] font-black px-3 py-1.5 rounded-lg shadow-sm shadow-emerald-100 print:border-2 print:border-black print:bg-white print:text-black uppercase">
                                        <i class="fas fa-check-circle text-[12px] print:hidden"></i> LUNAS
                                    </span>
                                @else
                                    <span class="inline-flex items-center gap-1.5 bg-orange-500 text-white text-[10px] font-black px-3 py-1.5 rounded-lg shadow-sm shadow-orange-100 print:border-2 print:border-black print:bg-white print:text-black uppercase animate-pulse">
                                        <i class="fas fa-clock text-[12px] print:hidden"></i> UNPAID
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    @endif

                </div>
            </div>
            
        </div>
        
        
    </div>
    
    
    
    
    
    
    {{-- FOOTER PAGE --}}
    <div class="text-center mt-6 opacity-50 text-[10px] text-slate-500 font-mono hidden print:block">
        Generated by PMB Online UBP Karawang | {{ date('d-m-Y H:i') }}
    </div>

</div>

{{-- CSS KHUSUS PRINT --}}
<style>
    @media print {
        @page { margin: 0; size: auto; }
        body { background: white !important; margin: 0; padding: 0; -webkit-print-color-adjust: exact; }
        .max-w-6xl { max-width: 100% !important; margin: 20px !important; padding: 0 !important; width: auto !important; }
        .print\:hidden, nav, footer, button, a { display: none !important; }
        
        /* CSS TABLE LAYOUT (AGAR SAMA TINGGI) */
        #print-container { display: table !important; width: 100% !important; border: 2px solid #000 !important; border-radius: 0 !important; box-shadow: none !important; margin: 0 !important; }
        .print-table-row { display: table-row !important; }
        #print-sidebar { display: table-cell !important; width: 30% !important; vertical-align: top !important; border-right: 1px solid #000 !important; background-color: #f8f8f8 !important; height: 100%; padding: 20px !important; }
        #print-content { display: table-cell !important; width: 70% !important; vertical-align: top !important; background-color: white !important; padding: 0 !important; }

        /* Colors & Borders */
        .bg-white, .bg-slate-50, .bg-blue-50 { background: white !important; }
        .text-slate-800, .text-blue-700, .text-slate-500, .text-blue-600 { color: black !important; }
        .border-b, .border-r, .border-l-4, .border { border-color: #ccc !important; }
        
        /* Grid Alignment */
        .grid { display: flex !important; flex-wrap: wrap !important; }
        .grid > div { width: 48% !important; margin-right: 2%; margin-bottom: 20px; }
        .grid.divide-x { display: table !important; width: 100%; border-bottom: 1px solid #000; }
        .grid.divide-x > div { display: table-cell !important; width: 25%; border-right: 1px solid #000; padding: 10px; }
        
        /* Cleanup */
        .shadow-2xl, .shadow-md, .shadow-sm { box-shadow: none !important; }
        img { max-width: 100% !important; }
    }
</style>
@endsection