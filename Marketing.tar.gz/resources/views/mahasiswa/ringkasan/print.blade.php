@php
    // --- SETUP VARIABLE LOGIC DI VIEW ---
    
    // 1. Logika Kelulusan
    // Mengubah text 'Lulus'/'Tidak Lulus' dari controller menjadi boolean
    $statusText = $statusUjian ?? 'Belum Ujian';
    $statusUpper = strtoupper($statusText);

    $isLulus = ($statusUpper === 'LULUS');
    $isGagal = ($statusUpper === 'TIDAK LULUS' || $statusUpper === 'GAGAL' || $statusUpper === 'REJECTED');

    // 2. Logika Keuangan
    // Mengubah status 'paid'/'unpaid' dari controller menjadi boolean
    $lunas = (isset($slikBillingStatus) && $slikBillingStatus == 'paid');
@endphp

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Manifest - {{ $user->name }}</title>
    {{-- Menggunakan Tailwind CSS via CDN untuk kemudahan (atau gunakan mix/vite Anda) --}}
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        /* SETUP HALAMAN CETAK A4 */
        @page {
            size: A4;
            margin: 0;
        }
        body {
            background: #e2e8f0; /* Background abu di layar */
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
        .sheet {
            background: white;
            width: 210mm;
            min-height: 297mm;
            margin: 20px auto;
            padding: 15mm;
            position: relative;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        
        /* SEMBUNYIKAN SAAT PRINT */
        @media print {
            body { background: none; }
            .sheet { margin: 0; width: 100%; height: 100%; box-shadow: none; border: none; }
            .no-print { display: none !important; }
        }

        /* WATERMARK BACKGROUND */
        .watermark-bg {
            background-image: url('{{ asset("images/logo_ubp.png") }}');
            background-repeat: no-repeat;
            background-position: center;
            background-size: 50%;
            opacity: 0.05;
        }

        /* TABEL DATA RAPIH */
        .data-table td {
            padding: 4px 0;
            vertical-align: top;
        }
        .label {
            color: #64748b;
            font-size: 0.75rem;
            text-transform: uppercase;
            font-weight: 700;
            width: 140px;
        }
        .value {
            color: #0f172a;
            font-weight: 600;
            font-size: 0.875rem;
        }
    </style>
</head>
<body>

    {{-- TOMBOL PRINT MENGAMBANG (HANYA DI LAYAR) --}}
    <div class="no-print fixed top-5 right-5 z-50 flex gap-2">
        <button onclick="window.print()" class="bg-blue-600 text-white px-6 py-3 rounded-full shadow-lg font-bold hover:bg-blue-700 transition flex items-center gap-2">
            <i class="fas fa-print"></i> Cetak Dokumen
        </button>
        <button onclick="window.close()" class="bg-slate-700 text-white px-6 py-3 rounded-full shadow-lg font-bold hover:bg-slate-800 transition">
            Tutup
        </button>
    </div>

    {{-- KERTAS A4 --}}
    <div class="sheet relative">
        
        {{-- Watermark Logo --}}
        <div class="absolute inset-0 watermark-bg pointer-events-none"></div>

        {{-- === HEADER DOKUMEN === --}}
        <header class="border-b-2 border-slate-800 pb-6 mb-6 flex justify-between items-end relative z-10">
            <div class="flex items-center gap-4">
                {{-- Ganti src dengan logo kampus Anda --}}
                <img src="{{ asset('images/logo_ubp.png') }}" alt="Logo Kampus" class="h-16 w-auto grayscale">
                <div>
                    <h1 class="text-2xl font-black text-slate-800 uppercase tracking-tight leading-none">Universitas Buana<br>Perjuangan</h1>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Panitia Penerimaan Mahasiswa Baru</p>
                </div>
            </div>
            <div class="text-right">
                <h2 class="text-xl font-bold text-slate-400 uppercase">Admission Manifest</h2>
                <p class="text-sm font-mono font-bold text-slate-800">REF: #{{ $ereg->trx_id ?? 'N/A' }}</p>
                <p class="text-[10px] text-slate-400">{{ date('d F Y, H:i') }}</p>
            </div>
        </header>

        {{-- === STATUS STAMP === --}}
        @if($isLulus)
            <div class="absolute top-10 right-10 border-4 border-green-600 text-green-600 px-6 py-2 text-2xl font-black uppercase tracking-widest opacity-20 transform -rotate-12 pointer-events-none">
                ACCEPTED
            </div>
        @elseif($isGagal)
            <div class="absolute top-10 right-10 border-4 border-red-600 text-red-600 px-6 py-2 text-2xl font-black uppercase tracking-widest opacity-20 transform -rotate-12 pointer-events-none">
                REJECTED
            </div>
        @endif

        {{-- === KONTEN UTAMA === --}}
        <div class="flex gap-8 relative z-10">
            
            {{-- KOLOM KIRI (FOTO & SUMMARY) --}}
            <div class="w-1/3">
                {{-- FOTO --}}
                <div class="w-full aspect-[3/4] bg-slate-100 border border-slate-300 rounded-lg mb-4 overflow-hidden relative flex items-center justify-center">
                    {{-- Mengambil Huruf Pertama dari Nama User --}}
                    <span class="text-8xl font-black text-slate-300 uppercase select-none">
                        {{ strtoupper(substr($user->name, 0, 1)) }}
                    </span>
                </div>

                {{-- STATUS CARD --}}
                <div class="bg-slate-50 border border-slate-200 rounded p-4 mb-4">
                    <h3 class="text-xs font-bold text-slate-800 border-b border-slate-200 pb-2 mb-2 uppercase">Status Pendaftaran</h3>
                    
                    <div class="space-y-3">
                        <div>
                            <span class="text-[10px] text-slate-500 uppercase font-bold block">Hasil Seleksi</span>
                            @if($isLulus)
                                <span class="text-sm font-bold text-green-700 bg-green-100 px-2 py-0.5 rounded">LULUS SELEKSI</span>
                            @elseif($isGagal)
                                <span class="text-sm font-bold text-red-700 bg-red-100 px-2 py-0.5 rounded">TIDAK LULUS</span>
                            @else
                                <span class="text-sm font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded">{{ strtoupper($statusText) }}</span>
                            @endif
                        </div>
                        <div>
                            <span class="text-[10px] text-slate-500 uppercase font-bold block">Keuangan</span>
                            @if($lunas)
                                <span class="text-sm font-bold text-slate-800">LUNAS / PAID</span>
                            @else
                                <span class="text-sm font-bold text-red-600">BELUM LUNAS</span>
                            @endif
                        </div>
                        <div>
                            <span class="text-[10px] text-slate-500 uppercase font-bold block">Sinkronisasi PDDIKTI</span>
                            <span class="text-sm font-bold {{ $dataFinal ? 'text-blue-600' : 'text-slate-400' }}">
                                {{ $dataFinal ? 'TERDATA' : 'PENDING' }}
                            </span>
                        </div>
                    </div>
                </div>

                
                
            </div>

            {{-- KOLOM KANAN (DETAIL DATA) --}}
            <div class="w-2/3">
                
                {{-- HEADER NAMA --}}
                <div class="mb-6">
                    <h2 class="text-2xl font-bold text-slate-900 uppercase leading-none mb-1">
                        {{ optional($dataFinal)->nama_mahasiswa ?? $biodata->nama_lengkap ?? $user->name }}
                    </h2>
                    <div class="text-sm font-mono text-slate-600 flex gap-4">
                        <span><i class="fas fa-envelope mr-1"></i> {{ $user->email }}</span>
                        <span><i class="fas fa-phone mr-1"></i> {{ optional($dataFinal)->handphone ?? $ereg->phone ?? '-' }}</span>
                    </div>
                </div>

                {{-- DATA PRIBADI --}}
                <div class="mb-6">
                    <h3 class="text-sm font-bold text-white bg-slate-800 px-2 py-1 mb-3 uppercase tracking-wide inline-block">Data Pribadi</h3>
                    <table class="w-full data-table">
                        <tr>
                            <td class="label">NIK (KTP)</td>
                            <td class="value">{{ optional($dataFinal)->nik ?? $biodata->nik ?? '-' }}</td>
                        </tr>
                        <tr>
                            <td class="label">TTL</td>
                            <td class="value">
                                {{ optional($dataFinal)->tempat_lahir ?? $biodata->tempat_lahir ?? '-' }}, 
                                {{ isset($dataFinal->tanggal_lahir) ? $dataFinal->tanggal_lahir->format('d F Y') : (isset($biodata->tanggal_lahir) ? \Carbon\Carbon::parse($biodata->tanggal_lahir)->format('d F Y') : '-') }}
                            </td>
                        </tr>
                        <tr>
                            <td class="label">Jenis Kelamin</td>
                            <td class="value">{{ $biodata->jenis_kelamin ?? '-' }}</td>
                        </tr>
                        <tr>
                            <td class="label">Alamat</td>
                            <td class="value">
                                {{ $dataFinal ? ($dataFinal->jalan . ', RT ' . $dataFinal->rt . '/RW ' . $dataFinal->rw . ', ' . $dataFinal->kelurahan . ', ' . $dataFinal->id_wilayah) : ($biodata->alamat ?? '-') }}
                            </td>
                        </tr>
                    </table>
                </div>

                {{-- DATA AKADEMIK --}}
                <div class="mb-6">
                    <h3 class="text-sm font-bold text-white bg-slate-800 px-2 py-1 mb-3 uppercase tracking-wide inline-block">Data Akademik</h3>
                    <table class="w-full data-table">
                        <tr>
                            <td class="label">Asal Sekolah</td>
                            <td class="value">{{ $biodata->asal_sekolah ?? '-' }} (Lulus: {{ $biodata->tahun_lulus ?? '-' }})</td>
                        </tr>
                        <tr>
                            <td class="label">Pilihan Prodi 1</td>
                            <td class="value">{{ $ereg->jurusan1_nama ?? '-' }}</td>
                        </tr>
                        <tr>
                            <td class="label">Pilihan Prodi 2</td>
                            <td class="value">{{ $ereg->jurusan2_nama ?? '-' }}</td>
                        </tr>
                        <tr>
                            <td class="label text-blue-700">DITERIMA DI</td>
                            <tr>
                                <td class="font-bold">Status Kelulusan</td>
                                <td>: {{ $statusUjian }}</td>
                            </tr>
                            <tr>
                                <td class="font-bold">Program Studi</td>
                                <td style="text-transform: uppercase;">
                                    : <strong>{{ $jurusanDiterima }}</strong>
                                </td>
                            </tr>
                        </tr>
                    </table>
                </div>

                {{-- DATA ORANG TUA --}}
                <div class="mb-6">
                    <h3 class="text-sm font-bold text-white bg-slate-800 px-2 py-1 mb-3 uppercase tracking-wide inline-block">Data Orang Tua</h3>
                    <table class="w-full data-table">
                        <tr>
                            <td class="label">Nama Ayah</td>
                            <td class="value">{{ $biodata->nama_ayah ?? '-' }}</td>
                        </tr>
                        <tr>
                            <td class="label">Nama Ibu</td>
                            <td class="value">{{ $biodata->nama_ibu ?? '-' }}</td>
                        </tr>
                        <tr>
                            <td class="label">Kontak Ortu</td>
                            <td class="value">{{ $biodata->dataFinal->handphone ?? '-' }}</td>
                        </tr>
                    </table>
                </div>

            </div>
        </div>

        {{-- === FOOTER & TANDA TANGAN === --}}
        <div class="mt-auto border-t-2 border-slate-800 pt-4 flex justify-between items-end relative z-10">
            
            {{-- Info Pembayaran (Kiri) --}}
            <div class="text-xs">
                @if($billing)
                    <p class="font-bold uppercase text-slate-500 mb-1">Informasi Pembayaran</p>
                    <div class="font-mono text-slate-800">
                        VA: <span class="font-bold">{{ $billing->virtual_account }}</span><br>
                        Nominal: Rp {{ number_format($billing->amount, 0, ',', '.') }}<br>
                        Status: {{ $lunas ? 'PAID' : 'UNPAID' }}
                    </div>
                @endif
            </div>

            {{-- Kolom Tanda Tangan (Kanan) --}}
            <div class="text-center w-48">
                <p class="text-xs font-bold text-slate-500 uppercase mb-12">Karawang, {{ date('d F Y') }}<br>Panitia PMB,</p>
                
                {{-- Garis TTD --}}
                <div class="border-b border-slate-800 mb-1"></div>
                <p class="text-xs font-bold text-slate-800 uppercase">Universitas Buana Perjuangan</p>
            </div>
        </div>

    </div>

    {{-- AUTO PRINT SCRIPT (Opsional) --}}
    <script>
        // window.print(); // Uncomment jika ingin langsung print saat halaman dibuka
    </script>
</body>
</html>