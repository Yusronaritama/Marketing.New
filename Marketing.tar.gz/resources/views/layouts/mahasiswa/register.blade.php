<!DOCTYPE html>
<html lang="id" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Pendaftaran Mahasiswa Baru') - UBP Karawang</title>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    @if (app()->environment('local', 'development'))
        <script src="https://cdn.tailwindcss.com"></script>
        <script>
            tailwind.config = {
                theme: {
                    extend: {
                        fontFamily: {
                            sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        },
                        colors: {
                            'ice': '#f1f5f9', 
                        },
                        boxShadow: {
                            'glass': '0 8px 32px 0 rgba(31, 38, 135, 0.37)',
                        }
                    }
                }
            }
        </script>
    @endif
    
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        [x-cloak] { display: none !important; }

        /* Background Utama: Deep Blue Gradient */
        body {
            background: radial-gradient(circle at top left, #1e3a8a, #172554, #0f172a);
            background-attachment: fixed;
            min-height: 100vh;
        }

        /* 1. GLASS PANEL UTAMA (Form Container) - LEBIH TRANSPARAN */
        .glass-card {
            /* PERUBAHAN DI SINI: Opacity diturunkan ke 0.7 (70%) */
            background: rgba(248, 250, 252, 0.70); 
            /* Blur dinaikkan agar teks tetap enak dibaca */
            backdrop-filter: blur(24px);
            -webkit-backdrop-filter: blur(24px);
            /* Border lebih tipis & transparan */
            border: 1px solid rgba(255, 255, 255, 0.3);
            /* Shadow lebih dalam */
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.25);
        }

        /* 2. GLASS NAVBAR */
        .glass-nav {
            background: rgba(255, 255, 255, 0.05); /* Sangat transparan */
            backdrop-filter: blur(12px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            color: white;
        }

        /* 3. INPUT STYLES (Solid White on Glass) */
        /* Input dibuat lebih solid (80%) agar kontras dengan kaca form */
        .form-input {
            background-color: rgba(255, 255, 255, 0.8); 
            border: 1px solid rgba(203, 213, 225, 0.6);
            transition: all 0.3s;
        }
        .form-input:focus {
            background-color: #ffffff;
            border-color: #3b82f6;
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.25);
            outline: none;
        }

        /* 4. RADIO CARDS */
        .radio-card-input { display: none; }
        .radio-card-label {
            position: relative;
            cursor: pointer;
            border: 1px solid rgba(255,255,255,0.4);
            background: rgba(255,255,255,0.6); /* Lebih transparan */
            transition: all 0.2s;
        }
        .radio-card-label:hover {
            background: rgba(255,255,255,0.9);
            border-color: #3b82f6;
        }
        .radio-card-input:checked + .radio-card-label {
            background: #ffffff;
            border-color: #3b82f6;
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.25);
        }
        /* Checkmark */
        .radio-card-input:checked + .radio-card-label::after {
            content: '\f00c';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            position: absolute;
            top: 0; right: 0;
            background: #3b82f6; color: white;
            padding: 4px 8px; font-size: 10px;
            border-bottom-left-radius: 8px;
        }

        /* Scrollbar */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.2); border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.4); }

        /* Animation */
        @keyframes float {
            0%, 100% { transform: translateY(0) scale(1); }
            50% { transform: translateY(-25px) scale(1.05); }
        }
        .blob { animation: float 10s infinite ease-in-out; }
    </style>
    @yield('styles')
</head>
<body class="antialiased selection:bg-blue-400 selection:text-white overflow-x-hidden text-slate-800">

    {{-- 1. DECORATIVE BACKGROUND BLOBS (Efek Cahaya LEBIH TERANG) --}}
    <div class="fixed inset-0 z-[-1] overflow-hidden pointer-events-none">
        <div class="blob absolute -top-10 -left-10 w-[30rem] h-[30rem] bg-blue-500 rounded-full mix-blend-screen filter blur-[90px] opacity-40"></div>
        <div class="blob absolute top-1/2 -right-20 w-[35rem] h-[35rem] bg-indigo-500 rounded-full mix-blend-screen filter blur-[90px] opacity-30" style="animation-delay: 2s"></div>
        <div class="blob absolute -bottom-20 left-10 w-[25rem] h-[25rem] bg-cyan-500 rounded-full mix-blend-screen filter blur-[80px] opacity-30" style="animation-delay: 4s"></div>
    </div>

    {{-- 2. NAVBAR --}}
    <nav class="fixed top-0 w-full z-50 glass-nav transition-all duration-300">
        <div class="max-w-6xl mx-auto px-4 sm:px-6">
            <div class="flex justify-between items-center h-20">
                {{-- Brand --}}
                <div class="flex items-center gap-3">
                    <div class="h-10 w-10 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 shadow-lg group hover:bg-white/20 transition-all">
                        <i class="fas fa-graduation-cap text-white text-lg group-hover:scale-110 transition-transform"></i>
                    </div>
                    <div class="flex flex-col text-white">
                        <span class="font-bold text-lg leading-tight tracking-tight">PMB Online</span>
                        <span class="text-[10px] uppercase tracking-wider opacity-70">Univ. Buana Perjuangan</span>
                    </div>
                </div>

                {{-- Menu --}}
                <a href="{{ route('mahasiswa.dashboard') }}" 
                   class="group flex items-center gap-2 rounded-full bg-white/10 px-5 py-2.5 text-sm font-semibold text-white transition-all hover:bg-white hover:text-blue-700 hover:shadow-[0_0_20px_rgba(255,255,255,0.3)] border border-white/20">
                    <i class="fas fa-columns transition-transform group-hover:rotate-180"></i>
                    <span class="hidden sm:inline">Dashboard</span>
                </a>
            </div>
        </div>
    </nav>

    {{-- 3. MAIN CONTENT --}}
    <main class="relative z-10 flex min-h-screen flex-col items-center justify-center pt-28 pb-12 px-4">
        
        <div class="w-full max-w-5xl">
            
            {{-- Header Text --}}
            <div class="text-center mb-10">
                <span class="inline-block py-1 px-4 rounded-full bg-white/10 border border-white/20 text-blue-100 text-[11px] font-bold uppercase tracking-widest backdrop-blur-sm mb-4 shadow-sm">
                    Tahun Akademik {{ date('Y') }}/{{ date('Y')+1 }}
                </span>
                <h1 class="text-3xl md:text-5xl font-extrabold text-white tracking-tight drop-shadow-xl mb-4">
                    Formulir Pendaftaran
                </h1>
                <p class="text-blue-100/90 text-sm md:text-base max-w-2xl mx-auto font-light leading-relaxed drop-shadow-sm">
                    Mohon isi data diri Anda dengan teliti. Data yang Anda masukkan akan diverifikasi oleh sistem kami.
                </p>
            </div>

            {{-- GLASS CARD CONTAINER (TRANSPARAN) --}}
            <div class="glass-card rounded-[2.5rem] p-6 md:p-10 lg:p-12 relative overflow-hidden">
                
                {{-- Kilauan --}}
                <div class="absolute -top-32 -left-32 h-64 w-64 bg-white opacity-10 blur-[60px] rounded-full pointer-events-none"></div>
                <div class="absolute top-0 right-0 h-full w-full bg-gradient-to-b from-white/5 to-transparent pointer-events-none"></div>

                {{-- CONTENT FORM --}}
                <div class="relative z-10">
                    @yield('content')
                </div>

            </div>

            {{-- Footer --}}
            <footer class="mt-10 text-center">
                <p class="text-xs text-blue-200/60 font-medium">
                    &copy; {{ date('Y') }} UBP Karawang. All rights reserved.
                </p>
                <div class="mt-3 flex justify-center gap-4 text-sm">
                    <a href="mailto:pmb@ubpkarawang.ac.id" class="flex items-center gap-2 text-blue-200 hover:text-white transition-colors hover:scale-105 transform">
                        <i class="far fa-envelope"></i> Bantuan Teknis
                    </a>
                </div>
            </footer>

        </div>
    </main>

    @yield('modals')
    @yield('scripts')
</body>
</html>