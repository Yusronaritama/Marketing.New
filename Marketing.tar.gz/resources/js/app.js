import './bootstrap';
import { loadRegisterForm } from './register-loader.js';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

// Export ke global scope untuk diakses dari Blade
window.registerStep = {
    loadRegisterForm
};
Alpine.start();
